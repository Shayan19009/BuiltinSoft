import React, { useEffect, useState } from "react";
import { img } from "../../assets/images/images";
import "../../assets/sass/Components/Footer/Footer.scss";
import {
  BsWhatsapp,
  BsFillTelephoneFill,
  BsEnvelopeFill,
  BsFillGeoAltFill,
} from "react-icons/bs";
import { FaFacebookF } from "react-icons/fa";
import { FaLinkedinIn } from "react-icons/fa6";
import { FaXTwitter } from "react-icons/fa6";
import useHook from "../HomePages/Experties/useHook";
import { useNavigate } from "react-router-dom";

export default function Footer() {
  const [expertiesData, setExpertiesData] = useState([]);
  const navigate = useNavigate();
  const { experties } = useHook();

  useEffect(() => {
    experties(setExpertiesData);
  }, []);

  return (
    <div className="footer">
      <div className="footerMenu">
        <div className="footer-link">
          <div>
            <div className="logoDiv">
              <img src={img.logo1} className="footerLogo" />
            </div>

            <div className="address">
              <h2>Office</h2>
              <p>
                Plot #7 Opposite Telenor Park Gate, Rahim Yar Khan, Pakistan
              </p>
            </div>
          </div>

          <div className="footer-social">
            <a href="https://wa.me/+923176777994" target="_blank">
              <BsWhatsapp className="socialIcon" />
            </a>

            <a href="https://www.facebook.com/builtinsoft/" target="_blank">
              <FaFacebookF className="socialIcon" />
            </a>

            <a href="https://twitter.com/BuiltinSoft" target="_blank">
              <FaXTwitter className="socialIcon" />
            </a>

            <a
              href="https://www.linkedin.com/company/builtinsoft/mycompany/"
              target="_blank"
            >
              <FaLinkedinIn className="socialIcon" />
            </a>
          </div>
        </div>

        <div className="footerServices">
          <h2 className="servicesHeading">Our Services</h2>
          <div>
            {expertiesData.map((item, index) => {
              return (
                <p
                  key={index}
                  className="servicesList"
                  onClick={() =>
                    navigate("/services", {
                      state: { selectedItemId: item._id },
                    })
                  }
                >
                  {item.heading}
                </p>
              );
            })}
          </div>
        </div>
        <div className="footerCompany">
          <h2>Company</h2>
          <p onClick={() => navigate("/AboutUs")}>About Us</p>
          <p   onClick={() => navigate("/contact")}>Contact Us</p>
          <p onClick={() => navigate("/portfolio")}>Portfolio</p>
          <p onClick={() => navigate("/blog")}>Blog</p>
          <p onClick={() => navigate("/career")}>Career</p>
        </div>
        <div className="footerContact">
          <h2>Contact</h2>
          <div className="iconDiv">
            <BsFillTelephoneFill className="contactIcon" />
            <p>+92 317 6777994</p>
          </div>
          <div className="iconDiv">
            <BsEnvelopeFill className="contactIcon" />
            <p>info@BuiltinSoft.com</p>
          </div>
          <div className="iconDiv">
            <BsFillGeoAltFill className="contactIcon" />
            <p>
              Plot #7 Opposite Telenor Park Gate,
              <br /> Rahimyar Khan, Pakistan
            </p>
          </div>
        </div>
      </div>
      <div className="copyright">
        <p>Copyright 2023 BuiltinSoft | With Love by BuiltinSoft</p>
      </div>
    </div>
  );
}
