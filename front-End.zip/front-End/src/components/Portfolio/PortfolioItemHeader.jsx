import styles from "../../assets/sass/Components/Portfolio/PortfolioItemHeader.module.scss";

function PortfolioItemHeader({PortfolioItemHeaderHeading}) {
  return (
    <div className={styles.blogDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>{PortfolioItemHeaderHeading}</p>
      </div>
    </div>
  );
}

export default PortfolioItemHeader;
