import styles from "../../assets/sass/Components/Portfolio/PortfolioHeader.module.scss";

function PortfolioHeader() {
  return (
    <div className={styles.borderDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>PORTFOLIO</p>
      </div>
    </div>
  );
}

export default PortfolioHeader;
