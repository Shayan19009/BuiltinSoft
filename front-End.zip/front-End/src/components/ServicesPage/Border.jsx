import "../../assets/sass/Components/ServicesPage/Border.module.scss";

function Border() {
  return (
    <div className="borderDiv">
      <div className="background">
        <div className="transbox"></div>
        <p className="heading">Website Development</p>
      </div>
    </div>
  );
}

export default Border;
