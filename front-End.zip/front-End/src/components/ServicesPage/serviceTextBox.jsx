import React, { useEffect, useState } from "react";
import "../../assets/sass/Components/ServicesPage/serviceTextBox.module.scss";
import useHook from "../HomePages/Experties/useHook";
import { Base_URL } from "../../Apis/ApiHandler";

function ServiceTextBox() {
  const [expertiesData, setExpertiesData] = useState([]);
  const { experties } = useHook();

  useEffect(() => {
    experties(setExpertiesData);
  }, []);

  return (
    <div className="serviceTextBoxContainer">
      <div className="headingDiv">
        <p className="subHeading">
          We strictly follow established business processes to develop
          innovative web solutions appreciated all over the world.
        </p>

        <h1 className="headingText">
          What is included in our web development services?
        </h1>
      </div>

      {expertiesData.map((item, index) => {
        return (
          <>
            <div className="imageTextDiv">
              <div className="leftDiv">
                <p >
                  <div
                  className="frontendText"
                    dangerouslySetInnerHTML={{
                      __html: item.description,
                    }}
                  />
                </p>
              </div>

              <div className="rightDiv">
                <img
                  src={Base_URL + item.image}
                  alt="laptop"
                  className="image"
                />
              </div>
            </div>
          </>
        );
      })}
    </div>
  );
}

export default ServiceTextBox;
