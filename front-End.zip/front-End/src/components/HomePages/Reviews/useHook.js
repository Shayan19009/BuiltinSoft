import React from "react";
import Api_Hits from "../../../Apis/Apis";

export default function useHook() {
  const reviews = async (setReviewsData) => {
    await Api_Hits.Reviews()
      .then((response) => {
        setReviewsData(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { reviews };
}
