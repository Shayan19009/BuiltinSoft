import React, { useEffect, useState, useRef } from "react";
import useHook from "./useHook";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import styles from "../../../assets/sass/Components/HomePage/Reviews/Reviews.module.scss";
import "swiper/css";
import AOS from "aos";

export default function Reviews() {
  const swiperRef = useRef();
  const [reviewsData, setReviewsData] = useState([]);
  const { reviews } = useHook();

  useEffect(() => {
    reviews(setReviewsData);
    AOS.init();
  }, []);

  return (
    <>
      <div
        className={`${styles["reviews-title"]} text-center`}
        data-aos="zoom-out"
      >
        <h1>Let’s Hear What Our Clients Say</h1>
        <p>
          We transform clients’ ideas into reality. Let’s see what made them
          love our work.
        </p>
      </div>

      <div className={styles.reviews}>
        <Swiper
          spaceBetween={10}
          centeredSlides={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: true,
          }}
          pagination={{
            clickable: true,
            renderBullet: function (index, className) {
              return `<div class="${styles.paginationDot} ${className}"></div>`;
            },
          }}
          modules={[Autoplay, Pagination, Navigation]}
          className={styles.mySwiper}
        >
          {reviewsData.map((item, index) => {
            return (
              <SwiperSlide key={index} className={styles.reviewSlider}>
                <div className={styles.reviewsCard}>
                  <p className={styles.quotes}>“</p>

                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="135"
                    height="18"
                    viewBox="0 0 135 18"
                    fill="none"
                    className={styles.svg}
                  >
                    <path
                      d="M18.6989 6.87504L11.9045 6.42835L9.34575 0L6.78695 6.42835L0 6.87504L5.20554 11.2951L3.49736 18L9.34575 14.3033L15.1942 18L13.486 11.2951L18.6989 6.87504Z"
                      fill="white"
                    />
                    <path
                      d="M76.6989 6.87504L69.9045 6.42835L67.3457 0L64.787 6.42835L58 6.87504L63.2055 11.2951L61.4974 18L67.3457 14.3033L73.1942 18L71.486 11.2951L76.6989 6.87504Z"
                      fill="white"
                    />
                    <path
                      d="M134.699 6.87504L127.905 6.42835L125.346 0L122.787 6.42835L116 6.87504L121.206 11.2951L119.497 18L125.346 14.3033L131.194 18L129.486 11.2951L134.699 6.87504Z"
                      fill="white"
                    />
                    <path
                      d="M47.6989 6.87504L40.9045 6.42835L38.3457 0L35.787 6.42835L29 6.87504L34.2055 11.2951L32.4974 18L38.3457 14.3033L44.1942 18L42.486 11.2951L47.6989 6.87504Z"
                      fill="white"
                    />
                    <path
                      d="M105.699 6.87504L98.9045 6.42835L96.3457 0L93.787 6.42835L87 6.87504L92.2055 11.2951L90.4974 18L96.3457 14.3033L102.194 18L100.486 11.2951L105.699 6.87504Z"
                      fill="white"
                    />
                  </svg>
                  <p>
                    <div
                      dangerouslySetInnerHTML={{
                        __html: item.message,
                      }}
                    />
                  </p>
                  <h1>{item.nameOfClient.toUpperCase()}</h1>
                  <h2>{item.postOfClient}</h2>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </>
  );
}
