import Api_Hits from "../../../Apis/Apis";

export default function useHook() {
  const experties = async (setExpertiesData) => {
    await Api_Hits.Experties()
      .then((responce) => {
        setExpertiesData(responce.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { experties };
}
