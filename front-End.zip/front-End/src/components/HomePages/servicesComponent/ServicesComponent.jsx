import React, { useEffect, useState } from "react";
import styles from "../../../assets/sass/Components/HomePage/ServicesComponent/ServicesComponent.module.scss";
import useHook from "./useHook";
import { Base_URL } from "../../../Apis/ApiHandler";
import AOS from "aos";
import { useNavigate } from "react-router-dom";

export default function ServicesComponent() {
  const [expertiesData, setExpertiesData] = useState([]);
  const { experties } = useHook();

  const navigate = useNavigate();

  useEffect(() => {
    experties(setExpertiesData);
    AOS.init();
  }, []);

  return (
    <div className={styles.ServicesComponent}>
      <div className={styles.expertiesTitle} data-aos="fade-up">
        <h1>Services</h1>
        <p>
          We build digital solutions with the latest technologies that line up
          with your business goals.
        </p>
      </div>

      <div className={styles.expertiesCardDiv} data-aos="fade-right">
        {expertiesData.map((item, index) => {
          return (
            <div
              key={index}
              className={styles.card}
              data-aos="zoom-in"
              onClick={() =>
                navigate("/services", {
                  state: { selectedItemId: item._id },
                })
              }
            >
              <img src={Base_URL + item.image} className={styles.cardImage} />
              <p>{item.heading}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
