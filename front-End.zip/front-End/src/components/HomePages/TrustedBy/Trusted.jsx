import useHook from "./useHook";
import "../../../assets/sass/Components/HomePage/TrustedBy/Trusted.scss";
import AOS from "aos";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "aos/dist/aos.css";
import { Base_URL } from "../../../Apis/ApiHandler";
import React, { useState, useEffect } from "react";
import SliderWrapper from "./_SlickSliderStyle";

export default function TrustedBy() {
  const [data, setData] = useState([]);
  const { TrustedBy } = useHook();

  useEffect(() => {
    TrustedBy(setData);
    AOS.init();
  }, []);

  const settings = {
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    initialSlide: 0,
    speed: 500,
    arrows: false,
    adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 4,
        }
        
      },
      {
        breakpoint: 425,
        settings: {
          slidesToShow: 4,
        }
        
      },
    ],
    appendDots: (dots) => <ul>{dots}</ul>,
    customPaging: (i) => (
      <div className="ft-slick__dots--custom">
        <div className="loading" />
      </div>
    ),
  };

  return (
    <div className="trusted flex-column ">
      <div className="trusted-title" data-aos="fade-right">
        <h1>Trusted By</h1>
      </div>

      <SliderWrapper>
        <Slider {...settings} className="slider">
          {data.map((item, index) => (
            <div className="slides" style={{ border: "none", outline: "none" }}>
              <img
                key={index}
                src={Base_URL + item.picture}
                alt="img"
                className="image"
                style={{ border: "none", outline: "none" }}
              />
            </div>
          ))}
        </Slider>
      </SliderWrapper>
    </div>
  );
}
