import React, { useEffect, useState } from "react";
import { wheels } from "../../../assets/images/images";
import "../../../assets/sass/Components/HomePage/Services/Services.scss";
import useHook from "./useHook";
import AOS from "aos";
import { Base_URL } from "./../../../Apis/ApiHandler";

export default function Services() {
  const { services } = useHook();
  const [servicesData, setServicesData] = useState([]);
  const [hoveredServiceIndex, setHoveredServiceIndex] = useState(null);

  useEffect(() => {
    services(setServicesData);
    AOS.init();
  }, []);

  const handleServiceMouseOver = (index) => {
    setHoveredServiceIndex(index);
  };

  const handleServiceMouseOut = () => {
    setHoveredServiceIndex(null);
  };

  return (
    <div className="services">
      <h1 className="service-title" data-aos="fade-down">
        Revolutionizing Businesses with Excellence and Expertise
      </h1>
      <div className="services-main">
        <div className="services-contanier" data-aos="fade-right">
          {servicesData.map((item, index) => {
            return (
              <div
                key={index}
                className="services-cart"
                onMouseOver={() => handleServiceMouseOver(index)}
                onMouseOut={handleServiceMouseOut}
              >
                <img src={Base_URL + item.picture} style={{ width: "80px" }} />
                <div>
                  <h3>{item.heading}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div
          className="services-wheel"
          style={{ position: "relative" }}
          data-aos="fade-left"
        >
          {wheels.map((item, index) => {
            return (
              <img
                key={index}
                src={item.wheel}
                style={{
                  width: item.width,
                  opacity: item.opacity
                    ? item.opacity
                    : hoveredServiceIndex === index ||
                      hoveredServiceIndex === null
                    ? 1
                    : 0.1,
                }}
                className="wheel-image"
                onMouseOver={() => handleServiceMouseOver(index)}
                onMouseOut={handleServiceMouseOut}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
