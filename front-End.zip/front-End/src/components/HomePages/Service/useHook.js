import React from "react";
import Api_Hits from "../../../Apis/Apis";

export default function useHook() {
  const services = async (setServicesData) => {
    await Api_Hits.Services()
      .then((responce) => {
        setServicesData(responce.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { services };
}
