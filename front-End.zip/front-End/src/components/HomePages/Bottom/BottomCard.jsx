import React, { useEffect, useState } from "react";
import styles from "../../../assets/sass/Components/HomePage/Bottom/BottomCard.module.scss";
import useHook from "../../../pages/Contect/useHook";
import { chooseUsBottomImg } from "../../../Arrays/Arrays";
import AOS from "aos";

function BottomCard() {
  const [bottomData, setBottomData] = useState([]);
  const { Contect } = useHook();
  useEffect(() => {
    Contect(setBottomData);
    AOS.init();
  }, []);

  return (
    <div className={styles.bottomCard}>
      {chooseUsBottomImg.map((item, index) => {
        return (
          <div key={index} className={styles.bottomCardData}>
            <h3>{item.name.toUpperCase()}</h3>
            <img
              src={item.img}
              alt="img"
              style={{ width: "20rem", height: "7rem" }}
            />
            <span className={styles.phone}>{item.phone}</span>
            <p>{item.location}</p>
          </div>
        );
      })}
    </div>
  );
}

export default BottomCard;
