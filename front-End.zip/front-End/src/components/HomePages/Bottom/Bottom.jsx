import React, { useEffect, useState } from "react";
import "../../../assets/sass/Components/HomePage/Bottom/Bottom.scss";
import useHook from "../../../pages/Contect/useHook";
import BottomForm from "../../Form/BottomForm";
import AOS from "aos";
import BottomFormHeading from "../Bottom/BottomFormHeading";
import BottomCard from "./BottomCard";

export default function Bottom() {
  const [bottomData, setBottomData] = useState([]);
  const { Contect } = useHook();
  useEffect(() => {
    Contect(setBottomData);
    AOS.init();
  }, []);
  return (
    <>
      <div className="bottom">
        <BottomFormHeading />
        <BottomForm />
        <BottomCard />
      </div>
    </>
  );
}
