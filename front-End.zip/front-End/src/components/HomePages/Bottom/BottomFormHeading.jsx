import { useEffect } from "react";
import AOS from "aos";
import styles from "../../../assets/sass/Components/HomePage/Bottom/BottomFormHeading.module.scss";

function BottomFormHeading() {
  useEffect(() => {
    AOS.init();
  }, []);

  return (
    <div className={styles.bottomTitle} data-aos="fade-up">
      <h1>Get In Touch With</h1>
      <h2>Our Experts</h2>
    </div>
  );
}

export default BottomFormHeading;
