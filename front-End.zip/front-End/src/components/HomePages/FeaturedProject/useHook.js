import React from 'react';
import Api_Hits from '../../../Apis/Apis';

export default function useHook() {
const featuredProject =async (setFeaturedData,setLoading) => {
    await Api_Hits.FeaturedProject()
    .then((responce)=>{setFeaturedData(responce.data.data)})
    .catch((error)=>{console.log(error)})
    .finally(()=>{setLoading(false)})
}    
return {featuredProject}
  
}
