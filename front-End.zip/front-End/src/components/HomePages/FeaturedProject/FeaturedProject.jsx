import React, { useEffect, useState, useRef } from "react";
import "../../../assets/sass/Components/HomePage/FeaturedProject/FeaturedProject.scss";
import useHook from "./useHook";
import { Autoplay } from "swiper/modules";
import { Navigation, Pagination, Scrollbar } from "swiper/modules";
import "swiper/css";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css/pagination";
import { useNavigate } from "react-router-dom";
import { Base_URL } from "../../../Apis/ApiHandler";
import AOS from "aos";
import "aos/dist/aos.css";

export default function FeaturedProject() {
  const swiperRef = useRef();
  const { featuredProject } = useHook();
  const [featuredData, setFeaturedData] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  useEffect(() => {
    featuredProject(setFeaturedData, setLoading);
    AOS.init();
  }, []);

  return (
    <div className="featured-project">
      {loading ? (
        ""
      ) : (
        <>
          <div className="featured-project-header text" data-aos="fade-left">
            <h1>Featured Project</h1>
            <p>
              Using the latest technology and industry expertise, we built
              top-end Android and iOS-based applications that add value to the
              business and user experience.
            </p>
          </div>

          <div className="featured-project-container">
            <Swiper  className="Swiper-control background-color" 
             
              spaceBetween={50}
              centeredSlides={true}
              autoplay={{
                autoplay: true,
                disableOnInteraction: true,
              }}
              modules={[Autoplay, Navigation, Pagination, Scrollbar]}
              slidesPerView={1}
              loop={true}
              onBeforeInit={(swiper) => {
                swiperRef.current = swiper;
                
              }}
            
            >
              {featuredData.map((item, index) => {
                return (
                  <SwiperSlide className="Swiper-Slider-control"
                    key={index}
                   style={{
                    backgroundColor: item.projecttheme,
                  }}
                   
                  >
                    <div className="featured-project-cart">
                      <img src={Base_URL + item.picture} />
                      <div className="featured-project-item">
                        <div className="itemImageDiv">
                          <img src={Base_URL + item.logo} />
                        </div>

                        <h2>{item.title}</h2>

                        <p>
                          <div
                            dangerouslySetInnerHTML={{
                              __html: item.description,
                            }}
                          />
                        </p>

                        <span>{item.location}</span>
                        <div></div>
                      </div>
                    </div>
                  </SwiperSlide>
                );
              })}
              ...
            </Swiper>
          </div>

          <div className="test-button">
            <svg
              onClick={() => swiperRef.current?.slidePrev()}
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M10 19.25C4.892 19.25 0.75 15.109 0.75 10C0.75 4.892 4.892 0.75 10 0.75C15.108 0.75 19.25 4.892 19.25 10C19.25 15.109 15.108 19.25 10 19.25Z"
                fill="#219EBC"
              />
              <path
                d="M11.4424 13.4717L7.95638 10.0007L11.4424 6.52968"
                stroke="white"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>

            <div className="view-more">
              <a
                className="view-more-btn"
                onClick={() => navigate("/portfolio")}
              >
                View More
              </a>
            </div>

            <svg
              onClick={() => swiperRef.current?.slideNext()}
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M10 19.25C15.108 19.25 19.25 15.109 19.25 10C19.25 4.892 15.108 0.75 10 0.75C4.892 0.75 0.75 4.892 0.75 10C0.75 15.109 4.892 19.25 10 19.25Z"
                fill="#219EBC"
              />
              <path
                d="M8.55762 13.4717L12.0436 10.0007L8.55762 6.52968"
                stroke="white"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </div>
        </>
      )}
    </div>
  );
}
