import React, { useEffect, useState } from "react";
import useHook from "./useHook";
import "../../../assets/sass/Components/HomePage/Stat/Stat.scss";
import { stat } from "./useHook";

export default function Stats() {
  const [statsData, setStatsData] = useState([]);
  const [loading, setLoading] = useState(true);

  const { stat, stats } = useHook();
  useEffect(() => {
    stats(setLoading);
  });
  return (
    <div className="stats ">
      <div className="stats-container flex-wrap ">
        {stat.map((item, index) => {
          return (
            <div key={index} className="stats-cart flex-column">
              <img src={item.image} className="statsIcon"/>
              <h2>{item.count}+</h2>
              <h3>{item.title}</h3>
            </div>
          );
        })}
      </div>
      <div></div>
    </div>
  );
}
