import React,{useState} from 'react'
import Api_Hits from '../../../Apis/Apis'
import experties from "../../../assets/images/Clients.gif";
import project from "../../../assets/images/project.gif";
import team from "../../../assets/images/team.gif";
import countries from "../../../assets/images/Countries.gif";

export default function useHook() {
  const [statsData,setStatsData] = useState([]);
  const stat = [
    {
      image: team,
      count: statsData.TeamMembers,
      title: "Expert Teams",
    },
    {
      image: project,
      count: statsData.developments,
      title: "Project Completed",
    },
    {
      image: countries,
      count: statsData.trusteds,
      title: "Win Awards",
    },
    {
      image: experties,
      count: statsData.epxertises,
      title: "experties",
    },
  ];
  const stats = async( setLoading) => {
    await Api_Hits.Stats()
    .then((responce)=>{setStatsData(responce.data.data)})
    .catch((error)=>{console.log(error)})
    .finally(()=>{setLoading(false)})
  }
    return {stat , stats}
  }
  