import React from 'react'
import Api_Hits from '../../../Apis/Apis'

export default function useHook() {
    const welcome = async(setWelcomeData , setLoading) =>{
        await Api_Hits.Welcome()
        .then((responce)=>{setWelcomeData(responce.data.data)})
        .catch((error)=>{console.log(error)})
        .finally(()=>{setLoading(false)})
    }
    return {welcome}
  
}
