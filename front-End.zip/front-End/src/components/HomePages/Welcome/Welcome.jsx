import React, { useEffect, useState } from "react";
import useHook from "./useHook";
import "../../../assets/sass/Components/HomePage/Welcome/Welcome.scss";
import { Base_URL } from "../../../Apis/ApiHandler";
import { useNavigate } from "react-router-dom";

export default function Welcome() {
  const [welcomeData, setWelcomeData] = useState([]);
  const [loading, setLoading] = useState(true);

  const { welcome } = useHook();
  const navigate = useNavigate();

  useEffect(() => {
    welcome(setWelcomeData, setLoading);
  }, []);
  return (
    <div className="welcome ">
      {loading ? (
        ""
      ) : (
        <>
          {welcomeData.map((item, index) => {
            return (
              <>
                <div className="container">
                  <div className='row'>
                    <div className="col-lg-6 col-md-6 col-12">
                      <div key={index} className="welcome-content ">
                        <div className="welcome-title fs-6">
                          <h1>{item.message}</h1>
                          <button onClick={() => navigate("/contact", {})}>
                            Contact Us
                          </button>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-6 col-md-6 col-12 text-center">
                        <img src={Base_URL + item.picture} className="welcomeImage w-50" />
                      </div>
                  </div>
                </div>
              </>
            );
          })}
        </>
      )}
    </div>
  );
}
