import React, { useEffect, useState } from "react";
import "../../../assets/sass/Components/HomePage/TechnologyStack/TechnologyStack.scss";
import useHook from "./useHook";
import { Base_URL } from "../../../Apis/ApiHandler";
import AOS from "aos";

export default function TechnologyStack() {
  const { TechnologyStack } = useHook();
  const [loading, setLoading] = useState(true);
  const [stackData, setStackData] = useState([]);
  const frontend = [];
  const backend = [];
  const native = [];
  const hybrid = [];

  useEffect(() => {
    handler();
    AOS.init();
  }, []);
  const handler = async () => {
    await TechnologyStack(setStackData, setLoading);
  };
  console.log(stackData);
  return (
    <>
      <div className="technology_stack flex-column text-center">
        <div
          className="technology-stack-title"
          data-aos="fade-up"
          data-aos-duration="3000"
        >
          <h1>Technology Stack</h1>
          <p>
            Our engineers apprehend your business requirements and help you
            choose the right technology for your solution.
          </p>
        </div>
        {!loading ? (
          <>
            {stackData.map((item, index) => {
              {
                if (item.developmentType === "web") {
                  if (item.stacktype === "frontend") {
                    frontend.push(item);
                  } else if (item.stacktype === "backend") {
                    backend.push(item);
                  }
                }
              }
              {
                if (item.developmentType === "app") {
                  <h1>{item.developmentType}</h1>;
                  if (item.stacktype === "native") {
                    native.push(item);
                  } else if (item.stacktype === "hybrid") {
                    hybrid.push(item);
                  }
                }
              }
            })}
            <div className="stacks flex-column">
              <div className="stack-app">
                <div className="stack-title">
                  <h2>Mobile Application Development Stack</h2>
                </div>
                <div className="stack-container">
                  <div
                    className="stack-native"
                    data-aos="fade-right"
                    data-aos-offset="300"
                    data-aos-easing="ease-in-sine"
                  >
                    <h3>Native</h3>
                    <div className="stack-item">
                      {native.map((item, index) => {
                        return (
                          <>
                            <div key={index} className="stack_items">
                              <img src={Base_URL + item.picture} />
                              <h4>{item.name}</h4>
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                  <div
                    className="stack-hybrid"
                    data-aos="fade-left"
                    data-aos-offset="300"
                    data-aos-easing="ease-in-sine"
                  >
                    <h3>Hybrid</h3>
                    <div className="stack-item">
                      {hybrid.map((item, index) => {
                        return (
                          <>
                            {" "}
                            <div key={index} className="stack_items">
                              <img src={Base_URL + item.picture} />
                              <h4>{item.name}</h4>
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
              <div className="stack-web">
                <div className="stack-title">
                  <h2>Website Application Development Stack</h2>
                </div>
                <div className="stack-container">
                  <div
                    className="stack-frontend"
                    data-aos="fade-right"
                    data-aos-offset="300"
                    data-aos-easing="ease-in-sine"
                  >
                    <h3>Front End</h3>
                    <div className="stack-item">
                      {frontend.map((item, index) => {
                        return (
                          <>
                            {" "}
                            <div key={index} className="stack_items">
                              <img src={Base_URL + item.picture} />
                              <h4>{item.name}</h4>
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                  <div
                    className="stack-backend"
                    data-aos="fade-left"
                    data-aos-offset="300"
                    data-aos-easing="ease-in-sine"
                  >
                    <h3>Back End</h3>
                    <div className="stack-item">
                      {backend.map((item, index) => {
                        return (
                          <>
                            {" "}
                            <div key={index} className="stack_items">
                              <img src={Base_URL + item.picture} />
                              <h4>{item.name}</h4>
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          ""
        )}
      </div>
    </>
  );
}
