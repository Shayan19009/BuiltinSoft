import Api_Hits from "../../../Apis/Apis";

export default function useHook() {
  const TechnologyStack = async ( setStackData,setLoading) => {
    await Api_Hits.TechnologyStacks()
      .then((responce) => {
        setStackData(responce.data.data);
      
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(()=>{setLoading(false)});
  };
  return {
    TechnologyStack,
  };
}
