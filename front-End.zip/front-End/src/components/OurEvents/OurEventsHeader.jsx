import styles from "../../assets/sass/Components/OurEvents/OurEventsHeader.module.scss";

function OurEventsHeader() {
  return (
    <div className={styles.borderDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>OUR EVENTS</p>
      </div>
    </div>
  );
}

export default OurEventsHeader;