import React, { useEffect, useState } from "react";
import { formData } from "../../Arrays/Arrays";
import "../../assets/sass/Components/Form/BottomForm.scss";
import AOS from "aos";
import axios from "axios";

export default function BottomForm() {
  useEffect(() => {
    AOS.init();
  }, []);

  const [contactformData, setFormData] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    message: "",
    requiredService: "",
  });

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    if (type === "radio") {
      setFormData({
        ...contactformData,
        requiredService: value,
      });
    } else {
      setFormData({
        ...contactformData,
        [name]: value,
      });
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const apiEndpoint = "http://192.168.100.50:5001/api/mails/";

    try {
      const response = await axios.post(apiEndpoint, contactformData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.status >= 200 && response.status < 300) {
        console.log("Form data sent successfully");
      } else {
        console.error("Failed to send form data");
      }
    } catch (error) {
      console.error("Error sending form data:", error);
    }
  };

  return (
    <form className="bottom-form " onSubmit={handleFormSubmit}>
      <div className="bottom-form-left " data-aos="fade-right">
        <h2>Contact Information</h2>
        <p>
          Fill up the form and our Team will get back to you within 24 hours.
        </p>
        <div className="form-left-container">
          {formData.map((item, index) => {
            return (
              <div key={index} className="form-left-cart">
                <img src={item.image} />
                <p>{item.name}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bottom-form-right" data-aos="fade-left">
        <div className="form-right-top">
          <div className="form-right-top-input">
            <label>Full Name</label>
            <input
              type="text"
              name="name"
              value={contactformData.name}
              onChange={handleInputChange}
            />
          </div>

          <div className="mailPhone">
            <div className="form-right-top-input">
              <label>Mail</label>
              <input
                type="email"
                name="email"
                value={contactformData.email}
                onChange={handleInputChange}
              />
            </div>

            <div className="form-right-top-input">
              <label>PhoneNumber</label>
              <input
                type="tel"
                name="phoneNumber"
                value={contactformData.phoneNumber}
                onChange={handleInputChange}
              />
            </div>
          </div>
        </div>

        <h4>What service do you need?</h4>

        <div className="form-right-options">
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id="flexRadioDefault1"
              value="Web Design"
              checked={contactformData.requiredService === "Web Design"}
              onChange={handleInputChange}
            />
            <label className="form-check-label" for="flexRadioDefault1">
              Web Design
            </label>
          </div>

          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id="flexRadioDefault2"
              value="App Design"
              checked={contactformData.requiredService === "App Design"}
              onChange={handleInputChange}
            />
            <label className="form-check-label" for="flexRadioDefault2">
              App Design
            </label>
          </div>

          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id="flexRadioDefault3"
              value="Graphic Design"
              checked={contactformData.requiredService === "Graphic Design"}
              onChange={handleInputChange}
            />
            <label className="form-check-label" for="flexRadioDefault3">
              Graphic Design
            </label>
          </div>

          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id="flexRadioDefault4"
              value="Digital Marketing"
              checked={contactformData.requiredService === "Digital Marketing"}
              onChange={handleInputChange}
            />
            <label className="form-check-label" for="flexRadioDefault4">
              Digital Marketing
            </label>
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id="flexRadioDefault5"
              value="Other"
              checked={contactformData.requiredService === "Other"}
              onChange={handleInputChange}
            />
            <label className="form-check-label" for="flexRadioDefault5">
              Other
            </label>
          </div>
        </div>
        <div className="form-right-message">
          <h4>Message</h4>
          <input
            type="text"
            placeholder="Write your message"
            style={{ width: "100%" }}
            name="message"
            value={contactformData.message}
            onChange={handleInputChange}
          />
          <button type="submit">Send Message</button>
        </div>
      </div>
    </form>
  );
}
