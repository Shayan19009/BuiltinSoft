import Api_Hits from "../../Apis/Apis";

export default function useHook() {

  const mails = async (setMailsData) => {
    await Api_Hits.Mails()
      .then((response) => {
        setMailsData(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { mails };
}
