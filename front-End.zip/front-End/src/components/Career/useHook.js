import Api_Hits from "../../Apis/Apis";

export default function useHook() {
  const vacancies = async (setVacanciesData) => {
    await Api_Hits.Vacancies()
      .then((responce) => {
        setVacanciesData(responce.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { vacancies };
}
