import styles from "../../assets/sass/Components/Career/Benefits.module.scss";
import teamIcon from "../../assets/images/teamIcon.svg";
import learningIcon from "../../assets/images/learningIcon.svg";
import securedIcon from "../../assets/images/securedIcon.svg";
import upgradeIcon from "../../assets/images/upgradeIcon.svg";

function Benefits() {
  return (
    <div className={styles.benefitsDiv}>
      <div className={styles.benefitColumn}>
        <p className={styles.benefits}>Benefits</p>
        <p className={styles.heading}>Why you Should Join Our Awesome Team</p>
        <p className={styles.description}>
          we want to feel like home when you are working at JMC(Japan Marketing
          & Consultancy Limited) & for that we have curated a great set of
          benefits for you.It all starts with the free lunch!
        </p>
      </div>

      <div className={styles.rightRow}>
        <div className={styles.firstColumn}>
          <div className={styles.teamIconDiv}>
            <img src={teamIcon} alt="team icon" className={styles.teamIcon} />
          </div>
          <p className={styles.rightRowHeading}>Team work</p>
          <p className={styles.rightRowDescription}>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry.
          </p>

          <div className={styles.learningIconDiv}>
            <img
              src={learningIcon}
              alt="learning icon"
              className={styles.learningIcon}
            />
          </div>
          <p className={styles.rightRowHeading}>Team Learning Opportunity</p>
          <p className={styles.rightRowDescription}>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry.
          </p>
        </div>

        <div className={styles.secondColumn}>
          <div className={styles.securedIconDiv}>
            <img
              src={securedIcon}
              alt="secured icon"
              className={styles.securedIcon}
            />
          </div>
          <p className={styles.rightRowHeading}>Secured Future</p>
          <p className={styles.rightRowDescription}>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry.
          </p>

          <div className={styles.upgradeIconDiv}>
            <img
              src={upgradeIcon}
              alt="upgrade icon"
              className={styles.upgradeIcon}
            />
          </div>
          <p className={styles.rightRowHeading}>Upgrade Skills</p>
          <p className={styles.rightRowDescription}>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Benefits;
