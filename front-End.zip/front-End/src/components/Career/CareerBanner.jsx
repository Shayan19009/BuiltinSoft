import styles from "../../assets/sass/Components/Career/CareerBanner.module.scss";
function CareerBanner() {
  return (
    <div className={styles.borderDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>JOIN US</p>
        <p className={styles.subHeading}>
          In publishing and graphic design, Lorem ipsum is a placeholder text
          commonly used to demonstrate the visual form of a document or a
          typeface without relying on meaningful content. Lorem ipsum may be
          used as a placeholder before final copy is available
        </p>
      </div>
    </div>
  );
}

export default CareerBanner;
