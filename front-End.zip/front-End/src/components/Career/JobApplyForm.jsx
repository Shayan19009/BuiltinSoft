import styles from "../../assets/sass/Components/Career/JobApplyForm.module.scss";
import React, { useEffect, useState } from "react";
import "../../assets/sass/Components/Form/BottomForm.scss";
import AOS from "aos";
import axios from "axios";

function JobApplyForm() {
  useEffect(() => {
    AOS.init();
  }, []);

  const [contactformData, setFormData] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    address: "",
    file: "",
    message: "",
  });

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;

    setFormData({
      ...contactformData,
      [name]: value,
    });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const apiEndpoint = "http://192.168.100.50:5001/api/mails/";

    try {
      // console.log("Form Data:", contactformData);
      const response = await axios.post(apiEndpoint, contactformData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.status >= 200 && response.status < 300) {
        console.log("Form data sent successfully");
      } else {
        console.error("Failed to send form data");
      }
    } catch (error) {
      console.error("Error sending form data:", error);
    }
  };

  return (
    <div className={styles.mainDiv}>
      <form className={styles.form} onSubmit={handleFormSubmit}>
        <h3>Please Enter your Details</h3>

        <div className={styles.inputDiv}>
          <div className={styles.formInput}>
            <label>
              Name <span>*</span>
            </label>
            <br />
            <input
              type="text"
              name="name"
              value={contactformData.name}
              onChange={handleInputChange}
            />
          </div>

          <div className={styles.formInput}>
            <label>
              Email <span>*</span>
            </label>
            <br />
            <input
              type="email"
              name="email"
              value={contactformData.email}
              onChange={handleInputChange}
            />
          </div>

          <div className={styles.formInput}>
            <label>
              Phone <span>*</span>
            </label>
            <br />
            <input
              type="tel"
              name="phoneNumber"
              value={contactformData.phoneNumber}
              onChange={handleInputChange}
            />
          </div>

          <div className={styles.formInput}>
            <label>
              Address <span>*</span>
            </label>
            <br />
            <input
              type="text"
              name="address"
              value={contactformData.address}
              onChange={handleInputChange}
            />
          </div>

          <div className={styles.formInput}>
            <label>
              Drop your CV here <span>*</span>
            </label>
            <br />
            <input
              className={styles.CVformInput}
              type="file"
              name="file"
              accept=".pdf, .doc, .docx"
              value={contactformData.file}
              onChange={handleInputChange}
              multiple={false}
            />
          </div>
        </div>

        <div className={styles.formMessage}>
          <p>
            Message <span>*</span>
          </p>
          <textarea
            type="text"
            name="message"
            value={contactformData.message}
            onChange={handleInputChange}
          />
          <button type="submit">Apply Now</button>
        </div>
      </form>
    </div>
  );
}

export default JobApplyForm;
