import React, { useEffect, useState } from "react";
import styles from "../../assets/sass/Components/Career/CareerOpenings.module.scss";
import useHook from "./useHook";
import { useNavigate } from "react-router-dom";

function CareerOpenings() {
  const [vacanciesData, setVacaniesData] = useState([]);
  const { vacancies } = useHook();

  const navigate = useNavigate();

  useEffect(() => {
    vacancies(setVacaniesData);

    window.scrollTo(0, 0);
  }, []);

  return (
    <div className={styles.mainDiv}>
      <p className={styles.subHeading}>Come join us</p>
      <h1 className={styles.heading}>Career Openings</h1>
      <p className={styles.description}>
        We’re always looking for creative, talented self-starters to join the
        JMC family. Check out our open roles below and fill out an application.
      </p>

      <div>
        {vacanciesData.map((item, index) => {
          const category = item.category;
          return (
            <div className={styles.listCard} key={index}>
              <div className={styles.column}>
                <p className={styles.heading}>Category</p>
                <p className={styles.data}> {category.name}</p>
              </div>

              <div className={styles.column}>
                <p className={styles.heading}>Experience</p>
                <p className={styles.data}> {item.experience}</p>
              </div>

              <div className={styles.column}>
                <p className={styles.heading}>Job Type</p>
                <p className={styles.data}> {item.jobType}</p>
              </div>

              <div className={styles.column}>
                <p className={styles.heading}>Deadline</p>
                <p className={styles.data}> {item.deadline}</p>
              </div>

              <button
                className={styles.applyButton}
                onClick={() => navigate("/job")}
              >
                Apply Now
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default CareerOpenings;
