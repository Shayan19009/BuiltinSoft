import "./Loader.css";

export default function Loader() {
  return (
    <div id="loader-overlay">
      <div className="loader-spinner"></div>
    </div>
  );
}
