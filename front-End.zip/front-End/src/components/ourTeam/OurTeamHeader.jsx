import styles from "../../assets/sass/Components/OurTeam/TeamHeader.module.scss";

function OurTeamHeader() {
  return (
    <div className={styles.borderDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>OUR TEAM</p>
      </div>
    </div>
  );
}

export default OurTeamHeader;