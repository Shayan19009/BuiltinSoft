import styles from "../../assets/sass/Components/Blogs/BlogMain.module.scss";
import AOS from "aos";
import React, { useEffect, useState } from "react";
import useHook from "./useHook";
import { useNavigate } from "react-router-dom";
import { Base_URL } from "../../Apis/ApiHandler";

function formatUpdatedAt(updatedAt) {
  const options = {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour12: true,
  };

  return new Date(updatedAt).toLocaleDateString("en-US", options);
}

function BlogMain() {
  const [blogData, setBlogData] = useState([]);
  const [recentBlogs, setRecentBlogs] = useState([]);
  const { blog } = useHook();
  const navigate = useNavigate();

  const handleReadMoreClick = (blogId) => {
    navigate(`/fullBlog/${blogId}`);
  };

  useEffect(() => {
    blog(setBlogData);
    AOS.init();

    const fetchRecentBlogs = async () => {
      try {
        const response = await fetch(Base_URL + `/api/blogs/`);
        const data = await response.json();

        if (data.success) {
          setRecentBlogs(data.recentBlogs);
        } else {
          console.error("Error fetching recent blogs:", data.message);
        }
      } catch (error) {
        console.error("Error fetching recent blogs:", error);
      }
    };

    fetchRecentBlogs();
  }, []);

  return (
    <div className={styles.mainBody}>
      <div className={styles.blogMainContainer}>
        {blogData.map((item, index) => {
          return (
            <div className={styles.container}>
              <div key={index} className={styles.blogDiv}>
                <div className={styles.mainContent}>
                  <img
                    src={Base_URL + item.coverpic}
                    className={styles.coverPic}
                  />
                  <p className={styles.heading}>{item.heading}</p>
                  <div
                    className={styles.previewText}
                    onClick={() => handleReadMoreClick(item._id)}
                  >
                    <p>{item.previewText}</p>
                  </div>
                  <a
                    className={styles.readMore}
                    onClick={() => handleReadMoreClick(item._id)}
                  >
                    Read More »
                  </a>
                  <div className={styles.dateDiv}>
                    <p className={styles.date}>
                      {formatUpdatedAt(item.updatedAt)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default BlogMain;
