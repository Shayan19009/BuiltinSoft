import React, { useEffect, useState } from "react";
import styles from "../../assets/sass/Components/Blogs/OurServices.module.scss";
import useHook from "../HomePages/Experties/useHook";
import { useNavigate } from "react-router-dom";

function OurServices() {
  const [expertiesData, setExpertiesData] = useState([]);
  const { experties } = useHook();
  const navigate = useNavigate();

  useEffect(() => {
    experties(setExpertiesData);
  }, []);

  return (
    <div className={styles.mainDiv}>
      <h1>Our Services</h1>

      {expertiesData.map((item, index) => {
        return (
          <p
            key={index}
            onClick={() =>
              navigate("/services", {
                state: { selectedItemId: item._id },
              })
            }
          >
            {item.heading}
          </p>
        );
      })}
    </div>
  );
}

export default OurServices;
