import Api_Hits from "../../Apis/Apis";

export default function useHook() {
  const blog = async (setBlogData) => {
    await Api_Hits.Blogs()
      .then((response) => {
        setBlogData(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return { blog };
}


