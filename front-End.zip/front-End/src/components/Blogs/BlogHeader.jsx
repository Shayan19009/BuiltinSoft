import styles from "../../assets/sass/Components/Blogs/BlogHeader.module.scss";

function BlogHeader() {
  return (
    <div className={styles.borderDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>BLOG</p>
      </div>
    </div>
  );
}

export default BlogHeader;
