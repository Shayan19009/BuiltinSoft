import styles from "../../assets/sass/Components/Blogs/SearchInput.module.scss";

const SearchInput = () => {
  return (
    <div className={styles.searchbar}>
      <input
        type="text"
        placeholder="Type & Hit Enter..."
        className={styles.placeholder}
      />
      <div className={styles.searchiconDiv}></div>
    </div>
  );
};

export default SearchInput;
