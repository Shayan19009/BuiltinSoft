import styles from "../../assets/sass/Components/Blogs/SingleBlogHeader.module.scss";

function SingleBlogHeader({ blogHeading }) {
  return (
    <div className={styles.blogDiv}>
      <div className={styles.background}>
        <div className={styles.transbox}></div>
        <p className={styles.heading}>{blogHeading}</p>
      </div>
    </div>
  );
}

export default SingleBlogHeader;
