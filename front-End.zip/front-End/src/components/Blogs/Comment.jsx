import styles from "../../assets/sass/Components/Blogs/Comment.module.scss";
import React, { useState } from "react";
import axios from "axios";
import CommentsList from "./CommentsList";

function Comment({ blogId }) {
  const [commentData, setCommentData] = useState({
    name: "",
    email: "",
    message: "",
    blogId: blogId,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    setCommentData({
      ...commentData,
      [name]: value,
      blogId: blogId,
    });
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();

    const apiEndpoint = "http://192.168.100.50:5001/api/blog-comments/";
    console.log("API Endpoint:", apiEndpoint);
    console.log("Comment Data:", commentData);

    try {
      const response = await axios.post(apiEndpoint, commentData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      console.log("Response:", response);

      if (response.status >= 200 && response.status < 300) {
        console.log("comment data sent successfully");

        setCommentData({
          name: "",
          email: "",
          message: "",
          blogId: blogId,
        });
      } else {
        console.error("Failed to send comment data");
      }
    } catch (error) {
      console.error("Error sending comment data:", error);
    }
  };

  return (
    <div className={styles.commentDiv}>
      <div className={styles.headingDiv}>
        <h1 className={styles.heading}>Leave a Reply</h1>
        <p>Your email address will not be published.</p>
        <p>Required fields are marked *</p>
      </div>

      <div className={styles.commentBox}>
        <form onSubmit={handleCommentSubmit}>
          <div className={styles.formGroup}>
            <label for="message">Comment *</label>
            <textarea
              id="message"
              name="message"
              type="text"
              value={commentData.message}
              onChange={handleInputChange}
            ></textarea>
          </div>

          <div className={styles.formGroup}>
            <label for="name">Name *</label>
            <input
              type="text"
              id="name"
              name="name"
              value={commentData.name}
              onChange={handleInputChange}
            />
          </div>

          <div className={styles.formGroup}>
            <label for="email">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              value={commentData.email}
              onChange={handleInputChange}
            />
          </div>

          <button type="submit" className={styles.btnSubmit}>
            Post Comment
          </button>
        </form>
      </div>

      <hr />

      <CommentsList blogId={blogId} />
    </div>
  );
}

export default Comment;
