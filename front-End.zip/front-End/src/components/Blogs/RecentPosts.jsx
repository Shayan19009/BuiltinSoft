import styles from "../../assets/sass/Components/Blogs/RecentPosts.module.scss";
import { Base_URL } from "../../Apis/ApiHandler";
import { useNavigate } from "react-router-dom";

function formatUpdatedAt(updatedAt) {
  const options = {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour12: true,
  };
  return new Date(updatedAt).toLocaleDateString("en-US", options);
}

function RecentPosts({ recentBlogs }) {
  const navigate = useNavigate();
  const handleBlogClick = (blogId) => {
    navigate(`/fullBlog/${blogId}`);
  };

  if (!recentBlogs || recentBlogs.length === 0) {
    return <div>No recent blogs</div>;
  }

  return (
    <div className={styles.recentPostsSection}>
      <p className={styles.recentPostsHeading}>Recent Posts</p>
      {recentBlogs && Array.isArray(recentBlogs) ? (
        recentBlogs.map((blog, index) => (
          <div
            className={styles.recentPost}
            key={index}
            onClick={() => handleBlogClick(blog._id)}
          >
            <div className={styles.recentPostImageDiv}>
              <img
                src={Base_URL + blog.coverpic}
                className={styles.recentPostImage}
                alt={`Recent Blog ${index + 1}`}
              />
            </div>
            <div className={styles.recentPostText}>
              <p className={styles.heading}>{blog.heading}</p>
              <p className={styles.date}>{formatUpdatedAt(blog.updatedAt)}</p>
            </div>
          </div>
        ))
      ) : (
        <p>No recent blogs available</p>
      )}
    </div>
  );
}

export default RecentPosts;
