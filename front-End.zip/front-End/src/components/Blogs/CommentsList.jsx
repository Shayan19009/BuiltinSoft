import { useEffect, useState } from "react";
import styles from "../../assets/sass/Components/Blogs/CommentsList.module.scss";
import useCommentsHook from "./useCommentsHook";

function CommentsList({ blogId }) {
  const [commentsList, setCommentsList] = useState([]);
  const { comments } = useCommentsHook(blogId);

  useEffect(() => {
    comments(setCommentsList);
  }, [comments, setCommentsList]);

  function formatUpdatedAt(updatedAt) {
    const options = {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour12: true,
    };

    return new Date(updatedAt).toLocaleDateString("en-US", options);
  }

  return (
    <div className={styles.authorDiv}>
      {commentsList.map((item, index) => {
        return (
          <div key={index}>
            <div className="authorName">
              <p className={styles.authorName}>{item.name}</p>
              <p className={styles.publishedDate}>
                {formatUpdatedAt(item.updatedAt)}
              </p>
              <p className={styles.authorInro}>{item.message}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default CommentsList;
