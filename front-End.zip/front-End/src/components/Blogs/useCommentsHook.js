import Api_Hits from "../../Apis/Apis";

export default function useCommentsHook(blogId) {
  const comments = async (setCommentsList) => {
    try {
      const response = await Api_Hits.Comments(blogId);
      setCommentsList(response.data.data);
    } catch (error) {
      console.error("Error fetching comments:", error);
    }
  };

  return { comments };
}
