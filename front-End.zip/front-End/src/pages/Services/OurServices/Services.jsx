import Layout from "../../../Layout/Layout";
import styles from "../../../assets/sass/Pages/Services/Services.module.scss";
import React, { useEffect, useState } from "react";
import useHook from "../../../components/HomePages/Experties/useHook";
import { Base_URL } from "../../../Apis/ApiHandler";
import { useLocation } from "react-router-dom";

export default function Services() {
  const location = useLocation();
  const selectedItemId = location?.state?.selectedItemId || null;
  const [expertiesData, setExpertiesData] = useState([]);
  const { experties } = useHook();

  useEffect(() => {
    experties(setExpertiesData)
      .then(() => console.log("Experties Data:", expertiesData))
      .catch((error) => console.error("Error fetching data:", error));

    window.scrollTo(0, 0);
  }, []);

  const selectedItem = expertiesData.find(
    (item) => item._id === selectedItemId
  );

  return (
    <Layout>
      {selectedItem && (
        <div>
          <div className={styles.borderDiv}>
            <div className={styles.background}>
              <div className={styles.transbox}></div>
              <p className={styles.heading}>{selectedItem.heading}</p>
            </div>
          </div>

          <div className={styles.headingDiv}>
            <p className={styles.subHeading}>
              We strictly follow established business processes to develop
              innovative web solutions appreciated all over the world.
            </p>

            <h1 className={styles.headingText}>
              What is included in our {selectedItem.heading} services?
            </h1>
          </div>

          <div className={styles.serviceTextBoxContainer}>
            <div className={styles.imageTextDiv}>
              <div className={styles.leftDiv}>
                <p className={styles.frontendText}>
                  <div
                    dangerouslySetInnerHTML={{
                      __html: selectedItem.description,
                    }}
                  />
                </p>
              </div>

              <div className={styles.rightDiv}>
                <img
                  src={Base_URL + selectedItem.picture}
                  alt="services image"
                  className={styles.image}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
