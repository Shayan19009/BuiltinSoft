import React, { useEffect } from "react";
import "../../assets/sass/Pages/HomePage/HomaePage.scss";
import "bootstrap/dist/css/bootstrap.css";
import Welcome from "../../components/HomePages/Welcome/Welcome";
import Trusted from "../../components/HomePages/TrustedBy/Trusted";
import FeaturedProject from "../../components/HomePages/FeaturedProject/FeaturedProject";
import Stats from "../../components/HomePages/stats/Stats";
import Services from "../../components/HomePages/Service/Services";
import Experties from "../../components/HomePages/Experties/Experties";
import TachnologyStacks from "../../components/HomePages/TechnologyStack/TechnologyStack";
import Layout from "../../Layout/Layout";
import Reviews from "../../components/HomePages/Reviews/Reviews";
import WhyChooseUs from "../../components/HomePages/WhyChooseUs/WhyChooseUs";
import Bottom from "../../components/HomePages/Bottom/Bottom";
import ServicesComponent from "../../components/HomePages/servicesComponent/ServicesComponent";

export default function HomePage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <div className="home-page">
        <section>
          <Welcome />
        </section>
        <section>
          <Stats />
        </section>
        <section>
          <Trusted />
        </section>
        <section>
          <FeaturedProject />
        </section>
        <section>
          <Services />
        </section>
        <section>
          <Experties />
        </section>
        <section>
          <ServicesComponent />
        </section>
        <section>
          <TachnologyStacks />
        </section>
        <section>
          <WhyChooseUs />
        </section>
        <section>
          <Reviews />
        </section>
        <section>
          <Bottom />
        </section>
      </div>
    </Layout>
  );
}
