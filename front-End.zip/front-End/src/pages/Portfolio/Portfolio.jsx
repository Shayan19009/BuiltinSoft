import React, { useEffect, useState } from "react";
import useHook from "../../components/HomePages/FeaturedProject/useHook";
import styles from "../../assets/sass/Components/Portfolio/Portfolio.module.scss";
import Layout from "../../Layout/Layout";
import { Base_URL } from "../../Apis/ApiHandler";
import PortfolioHeader from "../../components/Portfolio/PortfolioHeader";
import { useNavigate } from "react-router-dom";

export default function Portfolio() {
  const { featuredProject } = useHook();
  const [featuredProjectData, setFeaturedProjectData] = useState([]);
  const [loading, setLoading] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    featuredProject(setFeaturedProjectData, setLoading);
  });

  return (
    <Layout>
      <PortfolioHeader />
      <div className={styles.portfolio}>
        <div className={styles.headings}>
          <h1>Welcome to BuiltinSoft's portfolio page!</h1>
          <h5>Brand strategy and smart objectives</h5>
          <p>
            Here, you'll find some of the projects we've worked on and the
            clients we've had the pleasure of serving. Our team of skilled
            developers, designers, and project managers have helped businesses
            of all sizes achieve their goals through custom software development
            and digital solutions. Our portfolio showcases a diverse range of
            projects, from mobile apps to e-commerce websites and enterprise
            software. We take pride in our ability to understand our client's
            unique needs and tailor our approach to deliver the best possible
            results.
          </p>
        </div>

        <div className={styles.portfolioContainer}>
          {featuredProjectData.map((item, index) => {
            return (
              <>
                <div
                  onClick={() =>
                    navigate("/portfolioItem", {
                      state: { projectData: item },
                    })
                  }
                  className={styles.portfolioCard}
                  key={index}
                >
                  <img src={Base_URL + item.logo} />
                  <div className={styles.portfolioItem}>
                    <h2>{item.title}</h2>
                    <p>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.description,
                        }}
                      />
                    </p>
                  </div>
                </div>

                <div className={styles.portfolioCard} key={index}>
                  <img src={Base_URL + item.logo} />
                  <div className={styles.portfolioItem}>
                    <h2>{item.title}</h2>
                    <p>
                      Lorem ipsum dolor sit amet consectetur. Egestas ut urna
                      iaculis elit integer. Lorem ipsum dolor sit amet
                      consectetur. Egestas ut urna iaculis elit integer.
                    </p>
                  </div>
                </div>

                <div className={styles.portfolioCard} key={index}>
                  <img src={Base_URL + item.logo} />
                  <div className={styles.portfolioItem}>
                    <h2>{item.title}</h2>
                    <p>
                      Lorem ipsum dolor sit amet consectetur. Egestas ut urna
                      iaculis elit integer. Lorem ipsum dolor sit amet
                      consectetur. Egestas ut urna iaculis elit integer.
                    </p>
                  </div>
                </div>

                <div className={styles.portfolioCard} key={index}>
                  <img src={Base_URL + item.logo} />
                  <div className={styles.portfolioItem}>
                    <h2>{item.title}</h2>
                    <p>
                      Lorem ipsum dolor sit amet consectetur. Egestas ut urna
                      iaculis elit integer. Lorem ipsum dolor sit amet
                      consectetur. Egestas ut urna iaculis elit integer.
                    </p>
                  </div>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
