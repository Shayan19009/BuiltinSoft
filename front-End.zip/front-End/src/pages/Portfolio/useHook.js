import React from "react";

export default function useHook() {
  return <div></div>;
}
