import styles from "../../assets/sass/Pages/Portfolio/PortfolioItem.module.scss";
import { Base_URL } from "../../Apis/ApiHandler";
import { useLocation, useNavigate } from "react-router-dom";
import PortfolioItemHeader from "../../components/Portfolio/PortfolioItemHeader";
import React, { useEffect, useState } from "react";
import useHook from "../../components/HomePages/FeaturedProject/useHook";
import Layout from "./../../Layout/Layout";

function PortfolioItem() {
  const { featuredProject } = useHook();
  const [featuredProjectData, setFeaturedProjectData] = useState([]);
  const [loading, setLoading] = useState();
  const navigate = useNavigate();
  const { state } = useLocation();
  const { projectData } = state;

  useEffect(() => {
    featuredProject(setFeaturedProjectData, setLoading);
  });

  return (
    <Layout>
      <div className={styles.container}>
        <PortfolioItemHeader PortfolioItemHeaderHeading={projectData.title} />

        <div className={styles.itemDiv}>
          {projectData.allPicture.map((image, index) => (
            <div>
              <img
                key={index}
                className={styles.img}
                src={Base_URL + image}
                alt={`Project Image ${index + 1}`}
              />
            </div>
          ))}
        </div>

        <div className={styles.cardsRow}>
          <div className={styles.leftColumn}>
            <h3>Description</h3>
            <p>
              <div
                dangerouslySetInnerHTML={{
                  __html: projectData.description,
                }}
              />
            </p>
          </div>

          <div className={styles.rightColumn}>
            <h3>Front End</h3>
            <div className={styles.details}>
              {projectData.frontEnd.map((text, index) => (
                <p key={index}>{text}</p>
              ))}
            </div>

            <h3>Data Base</h3>
            <div className={styles.details}>
              {projectData.dataBase.map((text, index) => (
                <p key={index}>{text}</p>
              ))}
            </div>
            <h3>BackEnd</h3>
            <div className={styles.details}>
              {projectData.backEnd.map((text, index) => (
                <div>
                  <p key={index}>{text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default PortfolioItem;
