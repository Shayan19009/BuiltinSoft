import React from 'react';
import Api_Hits from '../../../Apis/Apis';

export default function useHook() {
  const OurTeam = (setOurTeamData) =>{
    Api_Hits.OurTeam()
    .then((responce)=>{ setOurTeamData(responce.data.data)})
    .catch((error)=>{console.log(error)})
  }
    return {OurTeam}
}
