import React, { useEffect, useState } from "react";
import Layout from "../../../Layout/Layout";
import useHook from "./useHook";
import "../../../assets/sass/Pages/OurTeam/OurTeam.scss";
import { Base_URL } from "../../../Apis/ApiHandler";
import OurTeamHeader from "../../../components/ourTeam/OurTeamHeader";
import teamBoss from "../../../assets/images/teamBoss.png";

export default function Team() {
  const [ourTeamData, setOurTeamData] = useState([]);
  const { OurTeam } = useHook();

  useEffect(() => {
    OurTeam(setOurTeamData);

    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <OurTeamHeader />
      <div className="ourteam">
        <div className="team-boss">
          <img src={teamBoss} />
          <h2>ADNAN MAJEED</h2>
          <h3>CEO</h3>
        </div>

        <div className="teamDiv">
          <div className="team-members-container">
            {ourTeamData.map((item, index) => {
              return (
                <div key={index} className="team-members-cart">
                  <div className="team-member-img">
                    <img src={Base_URL + item.picture} />
                  </div>
                  <h3>{item.name}</h3>
                  <p>{item.stack}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Layout>
  );
}
