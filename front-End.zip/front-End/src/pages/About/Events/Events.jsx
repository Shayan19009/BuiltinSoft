import React, { useEffect, useState } from "react";
import Layout from "../../../Layout/Layout";
import "../../../assets/sass/Pages/Events/Events.scss";
import useHook from "./useHook";
import { useNavigate } from "react-router-dom";
import { Base_URL } from "../../../Apis/ApiHandler";
import OurEventsHeader from "../../../components/OurEvents/OurEventsHeader";

export default function Events({ eventData, setEventData }) {
  const { Events } = useHook();

  useEffect(() => {
    Events(setEventData);

    window.scrollTo(0, 0);
  }, []);

  const navigate = useNavigate();
  const handleImageClick = (item) => {
    navigate(`/eventsdetail/${item._id}`);
  };

  return (
    <Layout>
      <div className="events">
        <OurEventsHeader />

        <div className="events-middle">
          <div className="events-middle-content">
            <h2>Unlock creativity and design without limits with Sublime</h2>

            <p>
              Brand strategy and smart objectives We start by listening and let
              that shape our design process, with our clients as partners every
              step of the way.Digital marketing and SEO We start by listening
              and let that shape our design process, with our clients as
              partners every step of the way.
            </p>
          </div>

          <div
            className="vedio-button"
            onClick={() =>
              window.open(
                "https://www.youtube.com/watch?v=SShA7nNEmlM",
                "_blank"
              )
            }
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 14 17"
              fill="none"
            >
              <g clip-path="url(#clip0_390_1998)">
                <path
                  d="M13.2625 6.95935L2.2625 0.456225C1.36875 -0.0719002 0 0.4406 0 1.74685V14.75C0 15.9219 1.27188 16.6281 2.2625 16.0406L13.2625 9.5406C14.2437 8.96247 14.2469 7.53747 13.2625 6.95935Z"
                  fill="white"
                />
              </g>
              <defs>
                <clipPath id="clip0_390_1998">
                  <rect
                    width="14"
                    height="16"
                    fill="white"
                    transform="translate(0 0.25)"
                  />
                </clipPath>
              </defs>
            </svg>
          </div>
          <img src="https://demo9.builtinsoft.com/wp-content/uploads/2023/04/video-thumbnil-for-events-page-01-scaled.jpg"></img>
        </div>

        <div className="bottomContent">
          {eventData.map((item, index) => (
            <>
              <div className="bottomDetails">
                <img
                  key={index}
                  src={Base_URL + item.coverpicture}
                  onClick={() => handleImageClick(item)}
                  alt={`Event ${index}`}
                />

                <h4>{item.title}</h4>
                <p>{item.previewText}</p>
              </div>
            </>
          ))}
        </div>
      </div>
    </Layout>
  );
}
