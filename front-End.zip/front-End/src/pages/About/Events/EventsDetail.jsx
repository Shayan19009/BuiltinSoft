import React from "react";
import { useParams } from "react-router-dom";
import styles from "../../../assets/sass/Pages/Events/EventsDetail.module.scss";
import { Base_URL } from "../../../Apis/ApiHandler";
import Layout from "./../../../Layout/Layout";

export default function EventsDetail({ eventData }) {
  const { eventId } = useParams();
  const event = eventData.find((item) => item._id === eventId);
  console.log(event);

  return (
    <Layout>
      <div>
        {event && (
          <div className={styles.eventDetail}>
            <div className={styles.borderDiv}>
              <div className={styles.background}>
                <div className={styles.transbox}>
                  <img src={Base_URL + event.grouppicture} alt={event.title} />
                </div>

                <p className={styles.heading}>{event.title}</p>
              </div>
            </div>

            <div className={styles.eventsMiddle}>
              <div className={styles.eventsMiddleContent}>
                <h2>{event.title}</h2>
                <p>
                  <div
                    dangerouslySetInnerHTML={{
                      __html: event.detailofevent,
                    }}
                  />
                </p>
              </div>

              <div
                className={styles.vedioButton}
                onClick={() =>
                  window.open(
                    "https://www.youtube.com/watch?v=SShA7nNEmlM",
                    "_blank"
                  )
                }
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 14 17"
                  fill="none"
                >
                  <g clip-path="url(#clip0_390_1998)">
                    <path
                      d="M13.2625 6.95935L2.2625 0.456225C1.36875 -0.0719002 0 0.4406 0 1.74685V14.75C0 15.9219 1.27188 16.6281 2.2625 16.0406L13.2625 9.5406C14.2437 8.96247 14.2469 7.53747 13.2625 6.95935Z"
                      fill="white"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_390_1998">
                      <rect
                        width="14"
                        height="16"
                        fill="white"
                        transform="translate(0 0.25)"
                      />
                    </clipPath>
                  </defs>
                </svg>
              </div>

              <img src={Base_URL + event.grouppicture} alt={event.title} />
            </div>

            <div className={styles.alleventimages}>
              {event.alleventimages &&
                event.alleventimages.map((image, index) => (
                  <img
                    key={index}
                    src={Base_URL + image}
                    alt={`Event ${index}`}
                  />
                ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
