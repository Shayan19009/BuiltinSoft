import React from 'react';
import Api_Hits from '../../../Apis/Apis';

export default function useHook() {
    const Events =async (setEventData) => {
       await Api_Hits.Events()
        .then((responce)=>{setEventData(responce.data.data)})
        .catch((error)=>{console.log(error)})
    }
  return {Events}
}
