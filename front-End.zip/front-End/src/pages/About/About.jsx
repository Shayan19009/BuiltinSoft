import React from "react";
import Layout from "../../Layout/Layout";

export default function About() {
  return (
    <Layout>
      <div>
        <h1>About us</h1>
      </div>
    </Layout>
  );
}
