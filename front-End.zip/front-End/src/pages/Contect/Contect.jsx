import React, { useEffect, useState } from "react";
import useHook from "./useHook";
import styles from "../../assets/sass/Pages/Contect/Contect.module.scss";
import Layout from "../../Layout/Layout";
import "bootstrap/dist/css/bootstrap.css";
import BottomForm from "./../../components/Form/BottomForm";
import BottomCard from "../../components/HomePages/Bottom/BottomCard";

export default function Contect() {
  const [contectData, setContectData] = useState([]);
  const { Contect } = useHook();

  useEffect(() => {
    Contect(setContectData);

    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <div className={styles.borderDiv}>
        <div className={styles.background}>
          <div className={styles.transbox}></div>
          <p className={styles.heading}>CONTACT US</p>
        </div>
      </div>

      <div className={styles.form}>
        <BottomForm />
        <BottomCard />
      </div>
    </Layout>
  );
}
