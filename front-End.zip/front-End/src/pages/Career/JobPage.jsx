import styles from "../../assets/sass/Pages/Career/JobPage.module.scss";
import React, { useEffect } from "react";
import Layout from "../../Layout/Layout";
import useHook from "../../components/Career/useHook";
import job from "../../assets/images/job.png";
import { useNavigate } from "react-router-dom";

function JobPage({ vacanciesData, setVacanciesData }) {
  const { vacancies } = useHook();
  const navigate = useNavigate();

  useEffect(() => {
    vacancies(setVacanciesData);

    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      {vacanciesData.map((item, index) => {
        const category = item.category;

        return (
          <div className={styles.mainDiv} key={index}>
            {/* --------Banner -----------*/}
            <div className={styles.borderDiv}>
              <div className={styles.background}>
                <div className={styles.transbox}></div>
                <p className={styles.heading}>{category.name}</p>
                <p className={styles.subHeading}>
                  Job Type: {item.jobType}&nbsp;&nbsp;No of Vacancies:{" "}
                  {item.numberOfVacancies}
                </p>

                <button
                  className={styles.applyButton}
                  onClick={() => navigate("/jobApply", {})}
                >
                  Apply Now
                </button>
              </div>
            </div>

            {/* -------------------------Banner Image------------------------------------ */}
            <div className={styles.bannerImgDiv}>
              <img src={job} alt="job" className={styles.bannerImg} />
            </div>

            <div className={styles.mainRow}>
              <div className={styles.leftColumn}>
                <h1 className={styles.jobTitle}>{category.name}</h1>
                <div>
                  <p className={styles.jobHeading}>Who Are We Looking For</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>What You Will Be Doing</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>
                    Bonus Points for Familiarity with
                  </p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>Educational Requirement</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>Salary</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>Working Hours</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>Working Days</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <div>
                  <p className={styles.jobHeading}>
                    Perks & Benefits You’ll Get{" "}
                  </p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>

                <hr />

                <div>
                  <p className={styles.jobHeading}>The Application Process</p>
                  <ul className={styles.jobList}>
                    <li>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: item.details,
                        }}
                      />
                    </li>
                  </ul>
                </div>
              </div>

              {/* ============Right Column============================================ */}
              <div className={styles.rightColumn}>
                <div className={styles.btnDiv}>
                  <button
                    className={styles.apply}
                    onClick={() => navigate("/jobApply", {})}
                  >
                    Apply Now
                  </button>
                </div>

                <div className={styles.jobSummaryDiv}>
                  <p className={styles.jobSummary}>Job Summary</p>

                  <div className={styles.details}>
                    <p className={styles.title}>Location</p>
                    <p className={styles.detail}>{item.location}</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Job Type</p>
                    <p className={styles.detail}>{item.jobType}</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Date posted</p>
                    <p className={styles.detail}>JOB POSTED ???</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Experience</p>
                    <p className={styles.detail}>{item.experience}</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Working Hours</p>
                    <p className={styles.detail}>{item.workingHours}</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Working Days</p>
                    <p className={styles.detail}>{item.workingDays}</p>
                  </div>

                  <div className={styles.details}>
                    <p className={styles.title}>Vacancy</p>
                    <p className={styles.detail}>{item.numberOfVacancies}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className={styles.divider}>
              <div className={styles.bottomDetails}>
                <p className={styles.jobHeading}>Our Statement</p>
                <p className={styles.jobList}>
                  Contrary to popular belief, Lorem Ipsum is not simply random
                  text. It has roots in a piece of classical Latin literature
                  from 45 BC, making it over 2000 years old. Richard McClintock,
                  a Latin professor at Hampden-Sydney College in Virginia,
                  looked up one of the more obscure Latin words, consectetur,
                  from a Lorem Ipsum passage, and going
                </p>

                <div className={styles.statementbtn}>
                  <button
                    className={styles.apply}
                    onClick={() => navigate("/jobApply", {})}
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </Layout>
  );
}

export default JobPage;
