import JobApplyForm from "../../components/Career/JobApplyForm";
import Layout from "../../Layout/Layout";
import React, { useEffect } from "react";

function JobApply() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <JobApplyForm />
    </Layout>
  );
}

export default JobApply;
