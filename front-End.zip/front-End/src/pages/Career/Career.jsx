import React, { useEffect } from "react";
import Layout from "../../Layout/Layout";
import CareerBanner from "../../components/Career/CareerBanner";
import Benefits from "../../components/Career/Benefits";
import CareerOpenings from "../../components/Career/CareerOpenings";


export default function Career() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <CareerBanner />
      <Benefits />
      <CareerOpenings />
    </Layout>
  );
}
