import React from "react";
import Layout from "../../Layout/Layout";
import BlogHeader from "../../components/Blogs/BlogHeader";
import BlogMain from "../../components/Blogs/BlogMain";
import { useEffect, useState, useRef } from "react";

export default function Blogs() {
  const [blogData, setBlogData] = useState([]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <Layout>
      <BlogHeader />
      <BlogMain />
    </Layout>
  );
}
