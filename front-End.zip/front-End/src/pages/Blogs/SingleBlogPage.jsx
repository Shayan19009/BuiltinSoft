import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import SingleBlogHeader from "../../components/Blogs/SingleBlogHeader";
import Layout from "../../Layout/Layout";
import styles from "../../assets/sass/Pages/Blogs/SingleBlogPage.module.scss";
import { Base_URL } from "../../Apis/ApiHandler";
import SearchInput from "../../components/Blogs/SearchInput";
import useHook from "../../components/Blogs/useHook";
import AOS from "aos";
import RecentPosts from "../../components/Blogs/RecentPosts";
import Comment from "../../components/Blogs/Comment";
import OurServices from "../../components/Blogs/OurServices";

function SingleBlogPage() {
  const [recentBlogs, setRecentBlogs] = useState([]);
  const [blogData, setBlogData] = useState([]);
  const { blogId } = useParams();
  const { blog } = useHook();

  useEffect(() => {
    const fetchBlogData = async () => {
      try {
        const response = await fetch(Base_URL + `/api/blogs/${blogId}`);
        const data = await response.json();

        if (data.success) {
          setBlogData(data.blog);
        } else {
          console.error("Error fetching blog data:", data.message);
        }
      } catch (error) {
        console.error("Error fetching blog data:", error);
      }
    };

    blog(setBlogData);
    AOS.init();
    fetchBlogData();

    const fetchRecentBlogs = async () => {
      try {
        const response = await fetch(Base_URL + "/api/recent-blogs");
        const data = await response.json();

        if (data.success) {
          setRecentBlogs(data.recentBlogs);
        } else {
          console.error("Error fetching recent blogs:", data.message);
        }
      } catch (error) {
        console.error("Error fetching recent blogs:", error);
      }
    };

    fetchRecentBlogs();
  }, []);

  if (!blogData.length) {
    return <div>Loading...</div>;
  }

  console.log(blogData);

  const specificBlog = blogData.find((blog) => blog._id === blogId);

  if (!specificBlog) {
    return <div>Loading...</div>;
  }

  return (
    <Layout>
      <SingleBlogHeader blogHeading={specificBlog.heading} />

      <div className={styles.body}>
        <div className={styles.mainColumn1}>
          <div className={styles.mainColumn}>
            <div className={styles.leftColumn}>
              <div>
                {specificBlog && (
                  <div>
                    <div className={styles.coverPicDiv}>
                      <img
                        src={Base_URL + specificBlog.coverpic}
                        className={styles.coverPicImage}
                        alt={specificBlog.heading}
                      />
                    </div>
                    <div
                      className={styles.blogTemplate}
                      dangerouslySetInnerHTML={{
                        __html: specificBlog.blogtemplate,
                      }}
                    />
                  </div>
                )}
              </div>
            </div>

            <div className={styles.rightColumn}>
              <SearchInput />
              <RecentPosts recentBlogs={blogData.slice(0, 3)} />
              <hr />

              <OurServices />
            </div>
          </div>

          <Comment blogId={specificBlog._id} />
        </div>
      </div>
    </Layout>
  );
}

export default SingleBlogPage;
