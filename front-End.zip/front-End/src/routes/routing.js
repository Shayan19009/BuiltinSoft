import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "../pages/HomePage/HomePage";
import Portfolio from "../pages/Portfolio/Portfolio";
import Services from "../pages/Services/OurServices/Services";
import About from "../pages/About/About";
import Career from "../pages/Career/Career";
import Team from "../pages/About/Team/Team";
import Events from "../pages/About/Events/Events";
import Contect from "../pages/Contect/Contect";
import EventsDetail from "../pages/About/Events/EventsDetail";
import Blogs from "../pages/Blogs/Blogs";
import SingleBlogPage from "../pages/Blogs/SingleBlogPage";
import JobPage from "../pages/Career/JobPage";
import PortfolioItem from "../pages/Portfolio/PortfolioItem";
import JobApply from "../pages/Career/JobApply";

export default function Routing() {
  const [eventData, setEventData] = useState([]);
  const [vacanciesData, setVacanciesData] = useState([]);
  const [blogData, setBlogData] = useState([]);

  const routes = [
    { path: "/", element: <HomePage /> },
    {
      path: "/portfolio",
      element: <Portfolio />,
    },
    {
      path: "/services",
      element: <Services />,
    },
    {
      path: "/blog",
      element: <Blogs />,
    },
    {
      path: "/About",
      element: <About />,
    },

    {
      path: "/AboutUs",
      element: <Team />,
    },

    {
      path: "/career",
      element: <Career />,
    },
    {
      path: "/events",
      element: <Events eventData={eventData} setEventData={setEventData} />,
    },
    {
      path: "/team",
      element: <Team />,
    },

    {
      path: "/job",
      element: (
        <JobPage
          vacanciesData={vacanciesData}
          setVacanciesData={setVacanciesData}
        />
      ),
    },

    {
      path: "/contact",
      element: <Contect />,
    },

    {
      path: "/eventsdetail/:eventId",
      element: <EventsDetail eventData={eventData} />,
    },

    { path: "/fullBlog/:blogId", element: <SingleBlogPage /> },

    { path: "/portfolioItem", element: <PortfolioItem /> },

    { path: "/jobApply", element: <JobApply /> },
  ];

  return (
    <BrowserRouter>
      <Routes>
        {routes.map((item, index) => (
          <Route key={index} path={item.path} element={item.element} />
        ))}
      </Routes>
    </BrowserRouter>
  );
}
