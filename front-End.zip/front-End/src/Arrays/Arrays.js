import download from "../assets/images/Why Should lounch/download.svg";
import RiseUp from "../assets/images/Why Should lounch/RiseUp.svg";
import megaPhone from "../assets/images/Why Should lounch/megaphone.svg";
import DriveDownload from "../assets/images/Why Should lounch/download-to-storage-drive.svg";
import UAE from "../assets/images/UAE.png";
import "../assets/sass/index.scss";
import dubai from "../assets/images/dubai.png";
import united from "../assets/images/united kingdom.png";
import PK from "../assets/images/pak.png";
import experties from "../assets/images/Clients.gif";
import project from "../assets/images/project.gif";
import team from "../assets/images/team.gif";
import countries from "../assets/images/Countries.gif";
import pakistan from "../assets/images/pakistan.png";
import phone from "../assets/images/formImg/Frame (1).png";
import mail from "../assets/images/formImg/Vector.png";
import paypal from "../assets/images/formImg/Group.png";
import loc from "../assets/images/formImg/Frame.png";
import tick from "../assets/images/tick_icon.svg";

const WhyshouldYouLouchYouProject = [
  {
    image: RiseUp,
    heading: "Rise in Downloads",
    description: "Mobile app downloading in the UAE surged 23% in 2022",
    color: "#D6C7FF",
  },
  {
    image: download,
    heading: "Increase in in-app purchases",
    description: "In-app purchases in the UAE increased by 9% in a year.",
    detail:
      "Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022",
    color: "#B4FFB4",
  },
  {
    image: megaPhone,
    heading: "Boost in app Installations",
    description: "Mobile apps got 41% more installations in 2022.",
    detail:
      "Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022",
    color: "#B4D5FF",
  },
  {
    image: DriveDownload,
    heading: "Popularity Among Businesses",
    description: "84%of UAE businesses are considering mobile apps.",
    detail:
      "Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022 Mobile app downloading in the UAE surged 23% in 2022",
    color: "#FFC7DC",
  },
];
const stat = [
  {
    image: team,
    count: 100,
    title: "Expert Teams",
  },
  {
    image: project,
    count: 220,
    title: "Project Completed",
  },
  {
    image: countries,
    count: 80,
    title: "Win Awards",
  },
  {
    image: experties,
    count: 150,
    title: "experties",
  },
];
const staticPhoneNumbers = [
  {
    image: PK,
    phone: "+92 176777994 ",
    borderRight: "white .2rem solid",
  },

  {
    image: UAE,
    phone: "+97 1556934112 ",
    borderRight: "white .2rem solid",
  },
  {
    image: PK,
    phone: "+92 3333388813 ",
  },
];
const ChooseUs = [
  {
    img: tick,
    name: "Quality",
    detail:
      "We aim to deliver high-quality products. Hence, we take care of everything at the granular level.We aim to deliver high-quality products.",
  },
  {
    img: tick,
    name: "Reliability",
    detail:
      "Our teams are made up of highly-skilled and certified engineers with industry-specific domain knowledge.",
  },
  {
    img: tick,
    name: "Flexibility",
    detail:
      "Our team keeps the requirements of our clients on priority & the development process transparent.",
  },
  {
    img: tick,
    name: "Competence",
    detail:
      " Our team consists of expert developers who have knowledge of domain expertise for all business industries.",
  },
];
const chooseUsBottomImg = [
  {
    img: dubai,
    name: "UNITED ARAB EMIRATES",
    phone: "+9711231234567",
    location: "#2011, Floor 20, Burjuman Business Tower, Dubai.",
  },
  {
    img: pakistan,
    name: "Pakistan",
    phone: "+921231234567",
    location: "Suite #304, 11200 Manchaca, Austin, Texas, US, 78748",
  },
  {
    img: united,
    name: "United Kingdom",
    phone: "+4421231234567",
    location: "Suite #304, 11200 Manchaca, Austin, Texas, US, 78748",
  },
];
const formData = [
  {
    image: phone,
    name: "+91 98765 43210",
  },
  {
    image: mail,
    name: "domain@paypal.com",
  },
  {
    image: paypal,
    name: "https://paypal.com",
  },
  {
    image: loc,
    name: "Location",
  },
];

export {
  staticPhoneNumbers,
  WhyshouldYouLouchYouProject,
  ChooseUs,
  chooseUsBottomImg,
  stat,
  formData,
};
