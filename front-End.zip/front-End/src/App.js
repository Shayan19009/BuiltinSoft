import "./App.css";
import Routing from "./routes/routing";

function App() {
  return (
    <div>
      <Routing />
    </div>
  );
}

export default App;
