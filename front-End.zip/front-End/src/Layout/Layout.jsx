import React from "react";
import "../assets/sass/layout/layout.scss";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import "bootstrap/dist/css/bootstrap.min.css";

export default function Layout({ children }) {
  return (
    <div>
      <Header />
      <main>{children}</main>
      <Footer />
    </div>
  );
}
