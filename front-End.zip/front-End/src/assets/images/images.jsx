import logo from './Logos/Builtinsoftlogo.png'
import logo1 from './Logos/Builtinsoft logo Official 4x-04.png'
import wheel1 from './wheels/builtinsoft wheel-01.webp';
import wheel2 from './wheels/builtinsoft wheel-02.webp';
import wheel3 from './wheels/builtinsoft wheel-03.webp';
import wheel4 from './wheels/builtinsoft wheel-04.webp';
import wheel5 from './wheels/builtinsoft wheel-05.webp';
import quotes from './quotes.png';
import telephone from './telephone.svg';
import dami from './Boss.png';
import whatsup from './Vector.png';
const wheels=[
 {
  wheel:wheel1,
  width: "48.1rem",
},
{

  wheel:wheel2,
  width: "40rem",
},
{
  wheel:wheel3,
  width: "30rem",
},
{
  wheel:wheel4,
  width: "18rem",

},
{
  wheel:wheel5,
  width: "9rem",
  opacity:1,

}
]
const img ={
  logo:logo,
  logo1:logo1,
  telephone:telephone,
  dami:dami,
  quotes:quotes,
  whatsup:whatsup,
}
export {img , wheels}