import { Base_URL, Request } from "./ApiHandler";

const Api_Hits = {
  TrustedBy: () => Request.get(Base_URL + "api/trusted"),
  Welcome: () => Request.get(Base_URL + "api/welcome"),
  Stats: () => Request.get(Base_URL + "api/stats/count"),
  FeaturedProject: () => Request.get(Base_URL + "api/developments"),
  TechnologyStacks: () => Request.get(Base_URL + "api/stacks"),
  Services: () => Request.get(Base_URL + "api/services"),
  Contect: () => Request.get(Base_URL + "api/contact"),
  Reviews: () => Request.get(Base_URL + "api/reviews"),
  OurTeam: () => Request.get(Base_URL + "api/ourteam"),
  Events: () => Request.get(Base_URL + "api/events"),
  Experties: () => Request.get(Base_URL + "api/expertise"),
  Blogs: () => Request.get(Base_URL + "api/blogs"),
  Mails: () => Request.post(Base_URL + "api/mails"),
  Comments: (blogId) =>
    Request.get(Base_URL + `api/blog-comments/getlive/${blogId}`),
  Vacancies: () => Request.get(Base_URL + "api/vacancies"),
};
export default Api_Hits;
