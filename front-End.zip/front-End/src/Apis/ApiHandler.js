import axios from "axios";
// export const Base_URL = process.env.REACT_APP_API_URL;
export const Base_URL = "http://localhost:5001/";
// export const Base_URL = "http://192.168.100.48:5001/";

export const Request = axios.create();
