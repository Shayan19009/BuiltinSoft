import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Stack extends Document {
  @Prop({ required: true })
  picture: string;

  @Prop({ required: true, type: String })
  developmentType: string;

  @Prop({ required: true, type: String })
  stacktype: string;


  @Prop({ required: true })
  name: string;
}

export const StackSchema = SchemaFactory.createForClass(Stack);
