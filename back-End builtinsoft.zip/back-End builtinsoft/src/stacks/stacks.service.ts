import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateStackDto } from './dto/create-stack.dto';
import { UpdateStackDto } from './dto/update-stack.dto';
import { Stack } from './stack.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { UploadService } from 'src/file-upload/upload.service';
import { ApiResponse } from 'src/dto/respose.dto';

@Injectable()
export class StacksService {
  constructor(
    @InjectModel(Stack.name)
    private readonly StackModel: Model<Stack>,
    private readonly uploadService: UploadService

  ) { }
  async create(createStackDto: CreateStackDto): Promise<Stack> {
    const createdStack = new this.StackModel(createStackDto);
    return await createdStack.save();
  }

  async findAll() {
    return await this.StackModel.find().sort({ createdAt: -1 }).exec()
  }

  async findOne(id: string) {
    return await this.StackModel.findById({ _id: id }).exec();
  }

  async update(id: String, updateStackDto: UpdateStackDto) {
    const updateStack = await this.StackModel.findByIdAndUpdate(
      id,
      updateStackDto,
      { new: true },
    );
    return updateStack;
  }
  async remove(id: string) {
    const stack = await this.StackModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(stack.picture)

    const result = await this.StackModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException('Stack record not found');
    } else {

      if (images.length > 0) {
        const data = await this.uploadService.deleteFiles(images)

        return new ApiResponse(true, data, 'success', null)

      }
      return result;
    }
  }
  async count(): Promise<number> {
    try {
      const count = await this.StackModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
