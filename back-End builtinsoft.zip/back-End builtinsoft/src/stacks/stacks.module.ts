import { Module } from '@nestjs/common';
import { StacksService } from './stacks.service';
import { StacksController } from './stacks.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Stack, StackSchema } from './stack.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Stack.name, schema: StackSchema },]),
    UploadedFile

  ],
  controllers: [StacksController],
  providers: [StacksService],
  exports: [StacksService]
})
export class StacksModule { }
