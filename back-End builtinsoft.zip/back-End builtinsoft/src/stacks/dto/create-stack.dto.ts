import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateStackDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
   picture: string;

  @ApiProperty({ type: String })
  @IsString()
  @IsNotEmpty()
   developmentType: string;

  @ApiProperty({ type: String })
  @IsString()
  @IsNotEmpty()
   stacktype: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
   name: string;
}
