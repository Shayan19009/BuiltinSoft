import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional } from 'class-validator';

export class UpdateStackDto{
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
   picture?: string;

  @ApiProperty({ required: false, type: String })
  @IsOptional()
  @IsString()
   developmentType?: string;

  @ApiProperty({ required: false, type: String })
  @IsOptional()
  @IsString()
   stacktype?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
   name?: string;
}
