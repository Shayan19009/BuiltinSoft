import { BadRequestException, Injectable } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';
@Injectable()
export class MailService {
  constructor(private readonly mailerService: MailerService) { }
  async sendEmail(email: string, subject: string, template: any): Promise<any> {
    try {
      await this.mailerService.sendMail({
        to: email,
        from: process.env.MAIL_FROM,
        subject: subject,
        html: template,
      });
    } catch (error) {
      console.log(error);

      throw new BadRequestException('Unable to send email');
    }
  }
}
