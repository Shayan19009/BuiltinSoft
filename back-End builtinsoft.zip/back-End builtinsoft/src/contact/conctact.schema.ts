import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Contact extends Document {

    // @Prop([
    //     {
    //         flag: { type: String, required: true },
    //         phoneNumber: { type: Number, required: true }
    //     }
    // ])
    // phoneNumbers: Record<string, any>[];


    @Prop({ type: Number, required: true })
    whatsappNo: number;

    @Prop({ type: String, required: true })
    email: string;

    @Prop({
        type: {
            lat: { type: Number, required: true },
            lon: { type: Number, required: true },
            officeName: { type: String },
            address: { type: String }
        },
    })
    location: Record<string, any>;



}

export const ContactSchema = SchemaFactory.createForClass(Contact);
export type ContactDocument = Contact & Document;
