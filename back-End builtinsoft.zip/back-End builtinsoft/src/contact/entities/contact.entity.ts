export class Contact {}
