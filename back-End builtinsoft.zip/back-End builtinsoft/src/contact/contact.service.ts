import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateContactDto } from './dto/create-contact.dto';
import { UpdateContactDto } from './dto/update-contact.dto';
import { Contact, ContactDocument } from './conctact.schema';

@Injectable()
export class ContactService {
  constructor(
    @InjectModel(Contact.name) private readonly contactModel: Model<ContactDocument>,
  ) { }

  async create(createContactDto: CreateContactDto) {
    const createdContact = new this.contactModel(createContactDto);
    return await createdContact.save();
  }

  async findAll(): Promise<Contact[]> {
    return await this.contactModel.find().sort({ createdAt: -1 }).exec();
  }

  async findOne(id: string): Promise<Contact | null> {
    return await this.contactModel.findById(id).exec();
  }

  async update(id: string, updateContactDto: UpdateContactDto) {
    return await this.contactModel.findByIdAndUpdate(id, updateContactDto, { new: true }).exec();
  }

  async remove(id: string) {
    await this.contactModel.findByIdAndRemove(id).exec();
  }
}
