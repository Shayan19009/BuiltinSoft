import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ContactService } from './contact.service';
import { CreateContactDto } from './dto/create-contact.dto';
import { UpdateContactDto } from './dto/update-contact.dto';
import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';

@Controller('contact')
@ApiTags('Contacts')
export class ContactController {
  constructor(private readonly contactService: ContactService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createContactDto: CreateContactDto) {
    try {
      const data = await this.contactService.create(createContactDto);
      if (data) {
        return new ApiResponse(true, data, 'Successfully added ', null)
      }
    } catch (err) {
      console.log(err);
      return new ApiResponse(false, null, 'Error', err.message);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.contactService.findAll();

      if (data) {
        return new ApiResponse(true, data, 'Success ', null)
      }
    } catch (err) {
      console.log(err);
      return new ApiResponse(false, null, 'Error', err.message);
    }
  }


  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.contactService.findOne(id);

      if (data) {
        return new ApiResponse(true, data, 'Success ', null)
      }
    } catch (err) {
      console.log(err);
      return new ApiResponse(false, null, 'Error', err.message);
    }
  }


  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateContactDto: UpdateContactDto) {
    try {
      const data = await this.contactService.update(id, updateContactDto);
      if (data) {
        return new ApiResponse(true, data, 'Successfully updated ', null)
      }
    } catch (err) {
      console.log(err);
      return new ApiResponse(false, null, 'Error', err.message);
    }

  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.contactService.remove(id);
      return new ApiResponse(true, data, 'Successfully deleted ', null)
    } catch (err) {
      console.log(err);
      return new ApiResponse(false, null, 'Error', err.message);
    }

  }
}
