import { ApiProperty } from "@nestjs/swagger";
import { IsArray, IsNumber, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';




class LocationDto {
    @IsNumber()
    @ApiProperty()
    lat: number;

    @IsNumber()
    @ApiProperty()
    lon: number;

    @IsString()
    @ApiProperty({ required: false })
    officeName?: string;

    @IsString()
    @ApiProperty({ required: false })
    address?: string;
}












export class CreateContactDto {



    @IsNumber()
    @ApiProperty()
    whatsappNo: number;

    @IsString()
    @ApiProperty()
    email: string;

    @ValidateNested()
    @Type(() => LocationDto)
    @ApiProperty({ type: LocationDto })
    location: LocationDto;


}

