import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateContactDto } from './create-contact.dto';
import { IsNumber, IsString } from 'class-validator';


class LocationDto {
    @IsNumber()
    @ApiProperty()
    lat: number;

    @IsNumber()
    @ApiProperty()
    lon: number;

    @IsString()
    @ApiProperty({ required: false }) // Optional field in Swagger
    officeName?: string;

    @IsString()
    @ApiProperty({ required: false }) // Optional field in Swagger
    address?: string;
}



export class UpdateContactDto extends PartialType(CreateContactDto) {
    @ApiProperty()
    whatsappNo?: number;

    @ApiProperty()
    email?: string;

    @ApiProperty()
    location?: LocationDto;


}
