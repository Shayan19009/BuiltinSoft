import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Event, EventSchema } from './event.schema';
import { Model } from 'mongoose';
import { UploadService } from 'src/file-upload/upload.service';
import { ApiResponse } from 'src/dto/respose.dto';

@Injectable()
export class EventsService {
  constructor(
    @InjectModel(Event.name)
    private readonly eventModel: Model<Event>,
    private readonly uploadService: UploadService
  ) { }

  async create(createEventDto: CreateEventDto): Promise<Event> {
    const createdEvent = new this.eventModel(createEventDto);
    return await createdEvent.save();
  }

  async findAll() {
    return await this.eventModel.find().sort({ createdAt: -1 }).exec();
  }

  async findOne(id: string) {
    const event = await this.eventModel.findById(id).exec();
    if (!event) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }
    return event;
  }

  async update(id: string, updateEventDto: UpdateEventDto) {
    const updatedEvent = await this.eventModel.findByIdAndUpdate(
      id,
      updateEventDto,
      { new: true }
    );
    if (!updatedEvent) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }
    return updatedEvent;
  }

  async remove(id: string) {
    const event = await this.eventModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(event.coverpicture)
    event.alleventimages.map((item, index) => {
      images.push(item)

    })

    const deletedEvent = await this.eventModel.findByIdAndDelete(id);
    if (!deletedEvent) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }
    if (images.length > 0) {
      const data = await this.uploadService.deleteFiles(images)

      return new ApiResponse(true, data, '', null)

    }
    else {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }

  }

  async count(): Promise<number> {
    try {
      const count = await this.eventModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
