import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { EventsService } from './events.service';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';
import { ApiTags } from '@nestjs/swagger';

@Controller('events')
@ApiTags('Events')
export class EventsController {
  constructor(private readonly eventsService: EventsService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createEventDto: CreateEventDto) {
    try {
      const data = await this.eventsService.create(createEventDto);
      if (data) {
        return new ApiResponse(true, data, 'added Successfully', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in adding ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.eventsService.findAll();
      if (data) {
        return new ApiResponse(true, data, 'Success', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in getting data ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.eventsService.findOne(id);
      if (data) {
        return new ApiResponse(true, data, 'Success', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in or data not found ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateEventDto: UpdateEventDto) {
    try {
      const data = await this.eventsService.update(id, updateEventDto);
      if (data) {
        return new ApiResponse(true, data, 'updated Successfully', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in updating ',
          null,
        );
      }
    } catch (error) {
    }
  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.eventsService.remove(id);
      return new ApiResponse(true, data, '', null)
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }
}
