import { Module } from '@nestjs/common';
import { EventsService } from './events.service';
import { EventsController } from './events.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { EventSchema } from './event.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Event', schema: EventSchema }]),
    UploadedFile
  ],
  controllers: [EventsController],
  providers: [EventsService],
  exports: [EventsService]

})
export class EventsModule { }
