// event.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { IsString, IsNotEmpty, IsUrl, ArrayNotEmpty, IsArray } from 'class-validator';

@Schema({ timestamps: true })
export class Event extends Document {
    @Prop()
    @IsString()
    @IsNotEmpty({ message: 'Title must not be empty' })
    title: string;

    @Prop()
    @IsString()
    @IsUrl({}, { message: 'Cover picture must be a valid URL' })
    @IsNotEmpty({ message: 'Cover picture must not be empty' })
    coverpicture: string;


    @Prop()
    @IsString()
    @IsUrl({}, { message: 'Group picture must be a valid URL' })
    @IsNotEmpty({ message: 'Group picture must not be empty' })
    previewText: string;

    @Prop()
    @IsString()
    @IsNotEmpty({ message: 'Detail of event must not be empty' })
    detailofevent: string;

    @Prop([String])
    @IsArray()
    @ArrayNotEmpty({ message: 'At least one event image must be provided' })
    @IsUrl({}, { each: true, message: 'All event images must be valid URLs' })
    alleventimages: string[];
}

export const EventSchema = SchemaFactory.createForClass(Event);

export type EventSchema = Document & Event; 