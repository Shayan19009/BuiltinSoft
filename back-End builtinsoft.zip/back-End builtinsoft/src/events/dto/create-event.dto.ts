import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsUrl, ArrayNotEmpty, IsArray } from 'class-validator';

export class CreateEventDto {
    @IsString()
    @ApiProperty()
    @IsNotEmpty({ message: 'Title must not be empty' })
    title: string;

    @ApiProperty()
    @IsString()
    @IsUrl({}, { message: 'Cover picture must be a valid URL' })
    @IsNotEmpty({ message: 'Cover picture must not be empty' })
    coverpicture: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty({ message: 'Group picture must not be empty' })
    previewText: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty({ message: 'Detail of event must not be empty' })
    detailofevent: string;

    @ApiProperty()
    @IsArray()
    @ArrayNotEmpty({ message: 'At least one event image must be provided' })
    @IsUrl({}, { each: true, message: 'All event images must be valid URLs' })
    alleventimages: string[];
}
