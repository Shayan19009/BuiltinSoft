import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateEventDto } from './create-event.dto';
import { IsString, IsUrl, IsOptional, IsArray } from 'class-validator';

export class UpdateEventDto extends PartialType(CreateEventDto) {

    @ApiProperty()
    @IsString()
    @IsOptional()
    title?: string;

    @ApiProperty()
    @IsString()
    @IsUrl({}, { message: 'Cover picture must be a valid URL' })
    @IsOptional()
    coverpicture?: string;

    @ApiProperty()
    @IsString()
    @IsOptional()
    previewText: string

    @ApiProperty()
    @IsString()
    @IsOptional()
    detailofevent?: string;

    @ApiProperty()
    @IsArray()
    @IsUrl({}, { each: true, message: 'All event images must be valid URLs' })
    @IsOptional()
    alleventimages?: string[];
}
