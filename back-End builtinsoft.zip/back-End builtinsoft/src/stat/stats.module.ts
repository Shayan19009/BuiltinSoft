import { Module } from '@nestjs/common';
import { DevelopmentsModule } from 'src/developments/developments.module';
import { OurteamModule } from 'src/ourteam/ourteam.module';
import { StatsController } from './stats.controller';
import { StatsService } from './stats.service';
import { TrustedModule } from 'src/trustedby/trusted.module';
import { ExpertiseModule } from 'src/expertise/expertise.module';
import { StacksModule } from 'src/stacks/stacks.module';
import { BlogsModule } from 'src/blogs/blogs.module';
import { ReviewsModule } from 'src/reviews/reviews.module';
import { VacanciesModule } from 'src/vacancies/vacancies.module';
import { EventsModule } from 'src/events/events.module';

// private StacksService: StacksService,
// private blogsService: BlogsService,
// private reviewsService: ReviewsService,
// private vacanciesService: VacanciesService,
// private eventsService: EventsService,
@Module({
    imports: [
        DevelopmentsModule,
        OurteamModule,
        TrustedModule,
        ExpertiseModule,
        StacksModule,
        BlogsModule,
        ReviewsModule,
        VacanciesModule,
        EventsModule,
    ],
    controllers: [StatsController],
    providers: [
        StatsService
    ],
})
export class Stats { }
