import { Injectable } from '@nestjs/common';
import { BlogsService } from 'src/blogs/blogs.service';
import { DevelopmentsService } from 'src/developments/developments.service';
import { EventsService } from 'src/events/events.service';
import { ExpertiseService } from 'src/expertise/expertise.service';
import { OurteamService } from 'src/ourteam/ourteam.service';
import { ReviewsService } from 'src/reviews/reviews.service';
import { StacksService } from 'src/stacks/stacks.service';
import { TrustedService } from 'src/trustedby/trusted.service';
import { VacanciesService } from 'src/vacancies/vacancies.service';

@Injectable()
export class StatsService {
    constructor(
        private development: DevelopmentsService,
        private teamService: OurteamService,
        private trustedService: TrustedService,
        private epxertiseService: ExpertiseService,
        private StacksService: StacksService,
        private blogsService: BlogsService,
        private reviewsService: ReviewsService,
        private vacanciesService: VacanciesService,
        private eventsService: EventsService,

    ) { }

    async getcount() {
        const developments = await this.development.count()
        const TeamMembers = await this.teamService.count()
        const trusteds = await this.trustedService.count()
        const epxertises = await this.epxertiseService.count()
        const Stacks = await this.StacksService.count()
        const blogs = await this.blogsService.count()
        const reviews = await this.reviewsService.count()
        const vacancies = await this.vacanciesService.count()
        const events = await this.eventsService.count()
        const data = {
            developments: developments,
            TeamMembers: TeamMembers,
            trusteds: trusteds,
            epxertises: epxertises,
            Stacks: Stacks,
            blogs: blogs,
            reviews: reviews,
            vacancies: vacancies,
            events: events
        }
        return data

    }


}