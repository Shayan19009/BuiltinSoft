import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';

import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';
import { StatsService } from './stats.service';


@Controller('stats')
@ApiTags('Stats')
export class StatsController {
    constructor(private readonly statsService: StatsService) { }
    @Get('/count')
    async count() {
        try {
            const data = await this.statsService.getcount();
            return new ApiResponse(true, data, 'success', null);
        } catch (error) {
            console.log(error);
            return new ApiResponse(false, null, 'Error', error.message);
        }
    }

}