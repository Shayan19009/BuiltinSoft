import { Injectable } from '@nestjs/common';
import { CreateWelcomeDto } from './dto/create-welcome.dto';
import { UpdateWelcomeDto } from './dto/update-welcome.dto';
import { Model } from 'mongoose'
import { Welcome } from './welcome.schema';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class WelcomeService {
  constructor(
    @InjectModel(Welcome.name)
    private readonly welcomeShema: Model<Welcome>,
  ) { } async create(createWelcomeDto: CreateWelcomeDto): Promise<Welcome> {
    const createdWelcome = new this.welcomeShema(createWelcomeDto);
    return await createdWelcome.save();
  }

  async update(id: string, updateWelcomeDto: UpdateWelcomeDto): Promise<Welcome> {
    return await this.welcomeShema.findByIdAndUpdate(id, updateWelcomeDto, { new: true });
  }


  async findAll() {
    return await this.welcomeShema.find().sort({ createdAt: -1 });
  }



}
