import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException, UseGuards } from '@nestjs/common';
import { WelcomeService } from './welcome.service';
import { CreateWelcomeDto } from './dto/create-welcome.dto';
import { UpdateWelcomeDto } from './dto/update-welcome.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';

@Controller('welcome')
@ApiTags('welcome Massage')
export class WelcomeController {
  constructor(private readonly welcomeService: WelcomeService) { }

  // @Post()
  // @UseGuards(AccessTokenGuard)
  // async create(@Body() createWelcomeDto: CreateWelcomeDto) {
  //   try {

  //     const data = await this.welcomeService.create(createWelcomeDto);
  //     if (data)
  //       return new ApiResponse(true, data, 'created successfully');
  //     else
  //       return new ApiResponse(false, null, 'Error', 'server side error');
  //   } catch (error) {
  //     return new ApiResponse(false, null, 'Error', error.message);
  //   }
  // }

  @Get()
  async findAll() {
    try {
      const data = await this.welcomeService.findAll();

      if (data)
        return new ApiResponse(true, data, 'created successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }


  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateWelcomeDto: UpdateWelcomeDto) {
    try {
      const data = await this.welcomeService.update(id, updateWelcomeDto);
      if (data)
        return new ApiResponse(true, data, 'created successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

}
