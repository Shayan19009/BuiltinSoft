import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateWelcomeDto } from './create-welcome.dto';
import {  IsString } from 'class-validator';

export class UpdateWelcomeDto extends PartialType(CreateWelcomeDto) {
    @ApiProperty({ description: 'The picture associated with the welcome message.' })
    @IsString()
    picture?: string;

    @ApiProperty({ description: 'The welcome message text.' })
    @IsString()
    message?: string;

}
