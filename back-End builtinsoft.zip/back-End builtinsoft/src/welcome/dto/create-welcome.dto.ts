import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class CreateWelcomeDto {


    @ApiProperty({ description: 'The picture associated with the welcome message.' })
    @IsNotEmpty()
    @IsString()
    picture: string;

    @ApiProperty({ description: 'The welcome message text.' })
    @IsNotEmpty()
    @IsString()
    message: string;
}

