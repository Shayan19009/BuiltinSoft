import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

@Schema({ timestamps: true })
export class Welcome extends Document {
    @ApiProperty({ description: 'The picture associated with the welcome message.' })
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    picture: string;

    @ApiProperty({ description: 'The welcome message text.' })
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    message: string;
}

export const WelcomeSchema = SchemaFactory.createForClass(Welcome);
export type WelcomeDocument = Welcome & Document;
