import { Module } from '@nestjs/common';
import { WelcomeService } from './welcome.service';
import { WelcomeController } from './welcome.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Welcome, WelcomeSchema } from './welcome.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Welcome.name, schema: WelcomeSchema }
    ]
      
    ),
  ],
  controllers: [WelcomeController],
  providers: [WelcomeService],
})
export class WelcomeModule {}
