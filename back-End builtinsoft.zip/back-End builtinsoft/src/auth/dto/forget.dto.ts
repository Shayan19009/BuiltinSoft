import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty } from "class-validator";

export class Forgot {
    @IsNotEmpty()
    @ApiProperty()
    username: string;


    @IsEmail()
    @IsNotEmpty()
    @ApiProperty()
    email: string;
}
export class Reset {
    @IsNotEmpty()
    @ApiProperty()
    token: string;


    @IsNotEmpty()
    @ApiProperty()
    newPassword: string;
}