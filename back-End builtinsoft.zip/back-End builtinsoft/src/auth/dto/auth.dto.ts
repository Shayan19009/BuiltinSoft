export class AuthDto {
    username: string;
    password: string;
}