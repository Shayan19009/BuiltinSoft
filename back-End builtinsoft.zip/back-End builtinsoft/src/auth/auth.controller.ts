import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Req,
} from '@nestjs/common';
import { Request } from 'express';
import { CreateUserDto } from 'src/user/dto/create-user.dto';
import { AuthService } from './auth.service';
import { AuthDto } from './dto/auth.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { ApiTags } from '@nestjs/swagger';
import { Forgot, Reset } from './dto/forget.dto';

@Controller('auth')
@ApiTags('auth')
export class AuthController {
  constructor(private authService: AuthService) { }

  @Post('signup')
  signup(@Body() createUserDto: CreateUserDto) {
    return this.authService.signUp(createUserDto);
  }

  @Post('forgot')
  async forgotpass(@Body() forgotdto: Forgot) {
    const data = await this.authService.forgotpassword(forgotdto);
    if (data) {
      return new ApiResponse(true, data, 'success', null)
    }
  }
  @Post('reset')
  async resetpass(@Body() resetdto: Reset) {

    const data = await this.authService.resetPassword(resetdto);
    if (data) {
      return new ApiResponse(true, data, 'success', null)
    }
  }

  @Post('signin')
  async signin(@Body() authdata: AuthDto) {
    const data = await this.authService.signIn(authdata);
    if (data) {
      return new ApiResponse(true, data, 'success', null)
    }
  }

  @Get('logout')
  logout(@Req() req: Request) {
    this.authService.logout(req.user['sub']);
  }
}