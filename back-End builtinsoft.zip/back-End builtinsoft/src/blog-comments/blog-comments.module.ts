import { Module } from '@nestjs/common';
import { BlogCommentsService } from './blog-comments.service';
import { BlogCommentsController } from './blog-comments.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Comments, CommentsSchema } from './comments-schema';

@Module({
  imports: [
    MongooseModule.forFeature(
      [{ name: Comments.name, schema: CommentsSchema }]
    )
  ],

  controllers: [BlogCommentsController],
  providers: [BlogCommentsService],
})
export class BlogCommentsModule { }
