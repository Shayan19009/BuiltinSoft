import { Controller, Get, Post, Body, Patch, Param, Delete, Put } from '@nestjs/common';
import { BlogCommentsService } from './blog-comments.service';
import { CreateBlogCommentDto } from './dto/create-blog-comment.dto';
import { UpdateBlogCommentDto } from './dto/update-blog-comment.dto';
import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';

@Controller('blog-comments')
@ApiTags('Blog Comments')
export class BlogCommentsController {
  constructor(private readonly blogCommentsService: BlogCommentsService) { }

  @Post()
  async create(@Body() createBlogCommentDto: CreateBlogCommentDto) {
    try {
      const data = await this.blogCommentsService.create(createBlogCommentDto);
      if (data) {
        return new ApiResponse(true, data, 'created successfully');
      }
      return new ApiResponse(false, data, 'something went wrong', 'erro');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':blogId')
  async findAll(@Param('blogId') blogId: string) {
    try {
      const data = await this.blogCommentsService.findAll(blogId);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
  @Get('/getlive/:blogId')
  async findLive(@Param('blogId') blogId: string) {
    try {
      const data = await this.blogCommentsService.findAllLive(blogId);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Post(':id')
  async handelActive(@Param('id') id: string) {
    try {
      const data = await this.blogCommentsService.ActiveInActiveTheComment(id);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.blogCommentsService.findOne(id);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateBlogCommentDto: UpdateBlogCommentDto) {

    try {
      const data = await this.blogCommentsService.update(id, updateBlogCommentDto);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
  @Put(':id')
  async ActiveUnActive(@Param('id') id: string) {
    try {
      const data = await this.blogCommentsService.ActiveInActiveTheComment(id);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    try {
      const data = await this.blogCommentsService.remove(id);

      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
}
