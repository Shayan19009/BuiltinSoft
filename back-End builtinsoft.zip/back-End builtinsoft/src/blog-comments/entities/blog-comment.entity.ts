export class BlogComment {}
