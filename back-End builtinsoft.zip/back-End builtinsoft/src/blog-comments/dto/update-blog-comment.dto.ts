import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateBlogCommentDto } from './create-blog-comment.dto';
import { IsNotEmpty, IsString, IsEmail } from 'class-validator';

export class UpdateBlogCommentDto extends PartialType(CreateBlogCommentDto) {

    @ApiProperty()
    @IsString()
    @IsEmail()
    email: string;

    @ApiProperty()
    @IsString()
    name: string;

    @ApiProperty()
    @IsString()
    blogId: string;

    @ApiProperty()
    @IsString()
    message: string;
}
