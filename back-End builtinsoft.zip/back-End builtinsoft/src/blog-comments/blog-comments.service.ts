import { Injectable } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { CreateBlogCommentDto } from './dto/create-blog-comment.dto';
import { UpdateBlogCommentDto } from './dto/update-blog-comment.dto';
import { Comments, CommentsDocument } from './comments-schema';

@Injectable()
export class BlogCommentsService {
  constructor(
    @InjectModel(Comments.name) private readonly CommentsModel: Model<CommentsDocument>,
  ) { }

  async create(createCommentsDto: CreateBlogCommentDto) {
    const createdComments = new this.CommentsModel(createCommentsDto);


    return await createdComments.save();
  }

  async findAll(blogId: string) {

    return await this.CommentsModel.find({ blogId: blogId }).exec();
  }
  async findAllLive(blogId: string) {

    return await this.CommentsModel.find({ blogId: blogId, isActive: true }).exec();
  }

  async findOne(id: string) {
    return await this.CommentsModel.findById(id).exec();
  }

  async update(id: string, updateCommentsDto: UpdateBlogCommentDto) {
    return await this.CommentsModel.findByIdAndUpdate(id, updateCommentsDto, { new: true }).exec();
  }
  async ActiveInActiveTheComment(id: string) {
    const comment = await this.CommentsModel.findById(id).exec();

    if (!comment) {
      return null;
    }

    comment.isActive = !comment.isActive;

    return await comment.save();
  }


  async remove(id: string) {
    return await this.CommentsModel.findByIdAndDelete(id).exec();
  }


}
