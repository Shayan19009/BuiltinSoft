import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { IsNotEmpty, IsString } from 'class-validator';

@Schema({ timestamps: true })
export class Comments extends Document {
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    email: string;

    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    name: string;

    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    blogId: string;

    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    message: string;

    @Prop({ required: true, type: Boolean, default: true })
    isActive: Boolean
}

export const CommentsSchema = SchemaFactory.createForClass(Comments);
export type CommentsDocument = Comments & Document;
