import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { VacanciesService } from './vacancies.service';
import { CreateVacancyDto } from './dto/create-vacancy.dto';
import { UpdateVacancyDto } from './dto/update-vacancy.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';
import { ApiResponse } from 'src/dto/respose.dto';
import { ApiTags } from '@nestjs/swagger';

@Controller('vacancies')
@ApiTags('Vacancies')
export class VacanciesController {
  constructor(private readonly vacanciesService: VacanciesService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createVacancyDto: CreateVacancyDto) {
    try {
      const data = await this.vacanciesService.create(createVacancyDto);

      if (data)
        return new ApiResponse(true, data, 'created successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.vacanciesService.findAll();
      if (data)
        return new ApiResponse(true, data, 'success');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.vacanciesService.findOne(id);

      if (data)
        return new ApiResponse(true, data, 'created successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateVacancyDto: UpdateVacancyDto) {
    try {
      const data = await this.vacanciesService.update(id, updateVacancyDto);

      if (data)
        return new ApiResponse(true, data, 'updated successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.vacanciesService.remove(id);

      if (data)
        return new ApiResponse(true, data, 'deleted successfully');
      else
        return new ApiResponse(false, null, 'Error', 'server side error');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
}
