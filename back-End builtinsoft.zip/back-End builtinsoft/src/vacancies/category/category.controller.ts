import {
    Controller,
    Get,
    Post,
    Body,
    Patch,
    Param,
    Delete,
    NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose'
import { ApiTags } from '@nestjs/swagger';
import { Category } from './category.schema';
import { ApiResponse } from 'src/dto/respose.dto';
import { CreateCategory } from './category.dto';



@Controller('category')
@ApiTags('Category')
export class CategoryController {
    constructor(
        @InjectModel(Category.name)
        private readonly categoryModel: Model<Category>
    ) { }
    @Post()
    async create(@Body() categorydto: CreateCategory) {
        try {
            categorydto.name = categorydto.name.toLocaleLowerCase()
            const category = await this.categoryModel.create(categorydto)
            const data = await category.save();
            console.log(data);

            return new ApiResponse(true, data, 'success', null)

        } catch (error) {
            new ApiResponse(true, null, 'success', error)

        }
    }

    @Get()
    async findAll() {
        const data = await this.categoryModel.find()
        return new ApiResponse(true, data, 'success', null)

    }


    @Get(':id')
    async findById(@Param('id') id: string) {
        const data = await this.categoryModel.find()
        return new ApiResponse(true, data, 'success', null)
    }

    @Patch(':id')
    async update(@Param('id') id: string, @Body() updateDto: CreateCategory) {
        const data = await this.categoryModel.findByIdAndUpdate(id, updateDto, { new: true })
        return new ApiResponse(true, data, 'success', null)
    }

    @Delete(':id')
    async remove(@Param('id') id: string) {
        const deletedVancance = await this.categoryModel.findByIdAndDelete(id);
        if (!deletedVancance) {
            throw new NotFoundException(`Event with ID ${id} not found`);
        }
        return deletedVancance;
    }
}