export class Vacancy {}
