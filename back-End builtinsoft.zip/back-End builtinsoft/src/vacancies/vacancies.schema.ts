import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { ObjectId } from 'mongodb';
import { IsNotEmpty, IsString, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Category } from './category/category.schema';



@Schema({ timestamps: true })
export class vacancies extends Document {
    @Prop({ type: ObjectId, ref: 'Category' })
    category: ObjectId;

    @ApiProperty()
    @Prop({ required: true, type: String })
    @IsNotEmpty()
    experience: string;

    @ApiProperty()
    @Prop({ required: true, type: String })
    @IsNotEmpty()
    jobType: string;

    @ApiProperty()
    @Prop({ required: true, type: String })
    @IsNotEmpty()
    coverPic: string;

    @ApiProperty()
    @Prop({ required: true, type: String })
    @IsNotEmpty()
    deadline: string;

    @ApiProperty()
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    location: string;

    @ApiProperty()
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    workingHours: string;

    @ApiProperty()
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    workingDays: string;

    @ApiProperty()
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    numberOfVacancies: string;

    @ApiProperty()
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    details: string;
}

export const vacanceSchema = SchemaFactory.createForClass(vacancies);
export type vacanceSchema = vacancies & Document;
