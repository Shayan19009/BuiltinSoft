import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateVacancyDto } from './create-vacancy.dto';
import { IsString } from 'class-validator';

export class UpdateVacancyDto extends PartialType(CreateVacancyDto) {
    @ApiProperty()
    @IsString()
    category?: string;

    @ApiProperty()
    @IsString()
    experience?: string;

    @ApiProperty()
    @IsString()
    jobType?: string;

    @ApiProperty()
    @IsString()
    deadline?: string;

    @ApiProperty()
    @IsString()
    location?: string;

    @ApiProperty()
    @IsString()
    workingHours?: string;

    @ApiProperty()
    @IsString()
    workingDays?: string;

    @ApiProperty()
    @IsString()
    numberOfVacancies?: string;

    @ApiProperty()
    @IsString()
    details?: string;
}
