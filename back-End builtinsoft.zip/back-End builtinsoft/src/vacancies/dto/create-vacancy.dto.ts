import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class CreateVacancyDto {
    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    category: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    experience: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    jobType: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    deadline: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    location: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    workingHours: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    workingDays: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    numberOfVacancies: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    details: string;
}
