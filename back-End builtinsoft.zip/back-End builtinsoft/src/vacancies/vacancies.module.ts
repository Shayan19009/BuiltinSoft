import { Module } from '@nestjs/common';
import { VacanciesService } from './vacancies.service';
import { VacanciesController } from './vacancies.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { vacanceSchema, vacancies } from './vacancies.schema';
import { Category, CategorySchema } from './category/category.schema';

@Module({
  imports: [
    MongooseModule.forFeature(
      [
        { name: vacancies.name, schema: vacanceSchema },
        { name: Category.name, schema: CategorySchema }
      ]
    )
  ],
  controllers: [VacanciesController],
  providers: [VacanciesService],
  exports: [VacanciesService]

})
export class VacanciesModule { }
