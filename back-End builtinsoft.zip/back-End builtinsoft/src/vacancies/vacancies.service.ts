import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateVacancyDto } from './dto/create-vacancy.dto';
import { UpdateVacancyDto } from './dto/update-vacancy.dto';
import { InjectModel } from '@nestjs/mongoose';
import { vacancies } from './vacancies.schema';
import { Model } from 'mongoose'
import { Category } from './category/category.schema';

@Injectable()
export class VacanciesService {
  constructor(
    @InjectModel(vacancies.name)
    private readonly vacanceModel: Model<vacancies>,
    @InjectModel(Category.name)
    private readonly categoryModel: Model<Category>,
  ) { }
  async create(createVacancyDto: CreateVacancyDto) {
    createVacancyDto.category = createVacancyDto.category.toLocaleLowerCase()
    const vacance = await this.vacanceModel.create(createVacancyDto)
    return await vacance.save();
  }

  async findAll() {
    return await this.vacanceModel.find({}).populate('category')
  }

  async findOne(id: string) {
    return await this.vacanceModel.findById({ _id: id });
  }

  async update(id: string, updateVacancyDto: UpdateVacancyDto) {
    return await this.vacanceModel.findByIdAndUpdate(id, updateVacancyDto, { new: true })
  }

  async remove(id: string) {
    const deletedVancance = await this.vacanceModel.findByIdAndDelete(id);
    if (!deletedVancance) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }
    return deletedVancance;
  }
  async count(): Promise<number> {
    try {
      const count = await this.vacanceModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}

