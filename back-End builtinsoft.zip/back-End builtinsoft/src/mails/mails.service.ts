import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateMailDto } from './dto/create-mail.dto';
import { UpdateMailDto } from './dto/update-mail.dto';
import { Mails, MailsSchema } from './mails.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as fs from 'fs/promises'
import { MailService } from 'src/utils/mailsender';

@Injectable()
export class MailsService {
  constructor(
    private mailService: MailService,
    @InjectModel(Mails.name) private readonly mailsModel: Model<Mails>,
  ) { }

  async create(createMailDto: CreateMailDto) {
    const templateContent = await fs.readFile('src/templates/user_message.mail.template.hbs', 'utf8');
    const template = templateContent
      .replaceAll('[User\'s Name]', createMailDto.name)
      .replaceAll('[User\'s Email]', createMailDto.email)
      .replace('[User\'s Phone Number]', createMailDto.phoneNumber)
      .replace('[User\'s Message]', createMailDto.message)
      .replace('[User\'s Subject]', createMailDto.requiredService);
    await this.mailService.sendEmail(createMailDto.email, createMailDto.requiredService, template)

    return await this.mailsModel.create(createMailDto)
  }

  async findAll() {
    return await this.mailsModel.find().sort({ createdAt: -1 })
  }

  async findOne(id: string) {
    return await this.mailsModel.findById({ _id: id })
  }

  async update(id: string, updateMailDto: UpdateMailDto) {
    return await this.mailsModel.findByIdAndUpdate(id, updateMailDto, { new: true }).exec();

  }

  async remove(id: string) {
    const deletedEvent = await this.mailsModel.findByIdAndRemove(id).exec();


    if (!deletedEvent) {
      throw new NotFoundException(`developmrent with ID ${id} not found`);
    }
    return deletedEvent

  }
}

