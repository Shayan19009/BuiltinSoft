import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsString } from "class-validator";

export class CreateMailDto {

    @IsString()
    @ApiProperty()
    name: string;

    @IsEmail()
    @ApiProperty()
    email: string;

    @IsString()
    @ApiProperty()
    phoneNumber: string;

    @IsString()
    @ApiProperty()
    message: string;

    @IsString()
    @ApiProperty()
    requiredService: string;


}
