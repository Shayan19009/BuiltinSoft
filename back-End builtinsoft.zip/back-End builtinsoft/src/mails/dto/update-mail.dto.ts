import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateMailDto } from './create-mail.dto';
import { Optional } from '@nestjs/common';

export class UpdateMailDto extends PartialType(CreateMailDto) {

    @Optional()
    @ApiProperty()
    name: string;

    @Optional()
    @ApiProperty()
    email: string;

    @Optional()
    @ApiProperty()
    phoneNumber: string;

    @Optional()
    @ApiProperty()
    message: string;

    @Optional()
    @ApiProperty()
    requiredService: string

}
