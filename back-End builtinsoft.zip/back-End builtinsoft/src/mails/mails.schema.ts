import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";



@Schema({ timestamps: true })
export class Mails {

    @Prop({ required: true, type: String })
    name: string;

    @Prop({ required: true, type: String })
    email: string;

    @Prop({ required: true, type: String })
    phoneNumber: string;

    @Prop({ required: true, type: String })
    message: string;

    @Prop({ required: true, type: String })
    requiredService: string;


}

export const MailsSchema = SchemaFactory.createForClass(Mails);
export type MailsSchema = Mails & Document;
