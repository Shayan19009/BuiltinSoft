import { Module } from '@nestjs/common';
import { MailsService } from './mails.service';
import { MailsController } from './mails.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Mails, MailsSchema } from './mails.schema';
import { MailService } from 'src/utils/mailsender';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Mails.name, schema: MailsSchema }]),
  ],
  controllers: [MailsController],
  providers: [MailsService,
    MailService
  ],
})
export class MailsModule { }
