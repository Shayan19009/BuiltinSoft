import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Trusted } from './trustedty.schema';
import { TrustedDto } from './dto/trusted.dto';
import { updateTrustedDto } from './dto/update-trusted';
import { ApiResponse } from 'src/dto/respose.dto';
import { UploadService } from 'src/file-upload/upload.service';

@Injectable()
export class TrustedService {
  constructor(
    @InjectModel(Trusted.name)
    private readonly trustedModel: Model<Trusted>,
    private readonly uploadService: UploadService

  ) { }

  async createTrusted(TrustedDto: TrustedDto): Promise<Trusted> {
    const createdTrusted = new this.trustedModel(TrustedDto);
    return createdTrusted.save();
  }

  async getAllTrusted(): Promise<Trusted[]> {
    return this.trustedModel.find().sort({ createdAt: -1 }).exec();
  }

  async getTrustedId(id: string): Promise<Trusted> {
    const trusted = await this.trustedModel.findById({ _id: id }).exec();
    if (!trusted) {
      throw new NotFoundException('Trusted record not found');
    }
    return trusted;
  }

  async updateTrusted(id: string, TrustedDto: updateTrustedDto): Promise<Trusted> {
    const updatedTrusted = await this.trustedModel.findByIdAndUpdate(
      id,
      TrustedDto,
      { new: true },
    );
    if (!updatedTrusted) {
      throw new NotFoundException('Trusted record not found');
    }
    return updatedTrusted;
  }

  async deleteTrusted(id: string) {

    const stack = await this.trustedModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(stack.picture)

    const result = await this.trustedModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException('Stack record not found');
    } else {

      if (images.length > 0) {
        const data = await this.uploadService.deleteFiles(images)

        return new ApiResponse(true, data, 'success', null)

      }
      return result;
    }
  }


  async count(): Promise<number> {
    try {
      const count = await this.trustedModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
