import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TrustedController } from './trusted.controller';
import { TrustedService } from './trusted.service';
import { Trusted, TrustedSchema } from './trustedty.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Trusted.name, schema: TrustedSchema }]),
    UploadedFile
  ],
  controllers: [TrustedController],
  providers: [TrustedService],
  exports: [TrustedService],
})
export class TrustedModule { }
