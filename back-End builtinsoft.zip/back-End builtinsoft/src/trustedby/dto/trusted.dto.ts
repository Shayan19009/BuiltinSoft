import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';




export class TrustedDto {
  @ApiProperty({ description: 'The picture associated with the trusted entity.' })
  @IsNotEmpty()
  @IsString()
  picture: string;

  @ApiProperty({ description: 'The name of the trusted entity.' })
  @IsNotEmpty()
  @IsString()
  name: string;


}
