import {  IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';




export class updateTrustedDto {
    @ApiProperty({ description: 'The picture associated with the trusted entity.' })
    @IsString()
    picture?: string;

    @ApiProperty({ description: 'The name of the trusted entity.' })
    @IsString()
    name?: string;


}
