import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

@Schema({ timestamps: true })
export class Trusted extends Document {
  @ApiProperty({ description: 'The picture associated with the trusted entity.' })
  @Prop({ required: true })
  @IsNotEmpty()
  @IsString()
  picture: string;

  @ApiProperty({ description: 'The name of the trusted entity.' })
  @Prop({ required: true })
  @IsNotEmpty()
  @IsString()
  name: string;
}

export const TrustedSchema = SchemaFactory.createForClass(Trusted);
export type TrustedDocument = Trusted & Document;
