import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { BlogsService } from './blogs.service';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { ApiTags } from '@nestjs/swagger';

@Controller('blogs')
@ApiTags('Blogs')
export class BlogsController {
  constructor(private readonly blogsService: BlogsService) { }

  @Post()
  async create(@Body() createBlogDto: CreateBlogDto) {
    try {
      const data = await this.blogsService.create(createBlogDto);
      return new ApiResponse(true, data, 'created successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.blogsService.findAll();
      return new ApiResponse(true, data, 'success get data');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.blogsService.findOne(id);
      return new ApiResponse(true, data, 'success to get id data');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateBlogDto: UpdateBlogDto) {
    try {
      const data = await this.blogsService.update(id, updateBlogDto);
      return new ApiResponse(true, data, 'updated successfully');

    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    try {
      const data = await this.blogsService.remove(id);
      return new ApiResponse(true, data, 'deleted successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
}
