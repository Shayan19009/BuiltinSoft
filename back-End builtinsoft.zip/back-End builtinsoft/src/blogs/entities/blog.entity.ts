export class Blog {}
