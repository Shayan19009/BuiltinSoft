// create-blog.dto.ts

import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateBlogDto {

    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    coverpic: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    heading: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    blogtemplate: string;

    @ApiProperty()
    @IsString()
    @IsNotEmpty()
    previewText: string;
}
