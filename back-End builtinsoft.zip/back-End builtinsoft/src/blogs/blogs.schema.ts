import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import { IsNotEmpty, IsString } from "class-validator";

@Schema({ timestamps: true })
export class Blogs extends Document {
    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    coverpic: string;

    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    heading: string;

    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    blogtemplate: string;



    @Prop({
        type: String, required: true
    })
    @IsNotEmpty()
    @IsString()
    previewText: string;
}

export const BlogsSchema = SchemaFactory.createForClass(Blogs);
export type BlogsSchema = Blogs & Document;
