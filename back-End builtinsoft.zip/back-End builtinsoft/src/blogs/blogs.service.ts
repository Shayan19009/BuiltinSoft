import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import { Blogs } from './blogs.schema';
import { ApiResponse } from 'src/dto/respose.dto';
import { UploadService } from 'src/file-upload/upload.service';

@Injectable()
export class BlogsService {
  constructor(
    @InjectModel(Blogs.name)
    private readonly blogModel: Model<Blogs>,
    private readonly uploadService: UploadService,

  ) { }

  async create(createBlogDto: CreateBlogDto) {
    const createdBlog = new this.blogModel(createBlogDto);
    return await createdBlog.save();
  }

  async findAll() {
    return this.blogModel.find().sort({ createdAt: -1 }).exec();
  }

  async findOne(id: string) {
    const blog = await this.blogModel.findById(id).exec();
    if (!blog) {
      throw new NotFoundException(`Blog with ID ${id} not found`);
    }
    return blog;
  }

  async update(id: string, updateBlogDto: UpdateBlogDto) {
    const updatedBlog = await this.blogModel
      .findByIdAndUpdate(id, updateBlogDto, { new: true })
      .exec();

    if (!updatedBlog) {
      throw new NotFoundException(`Blog with ID ${id} not found`);
    }

    return updatedBlog;
  }

  async remove(id: string) {


    const blog = await this.blogModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(blog.coverpic)

    const result = await this.blogModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException('Stack record not found');
    } else {

      if (images.length > 0) {
        const data = await this.uploadService.deleteFiles(images)

        return new ApiResponse(true, data, 'success', null)

      }
      return result;
    }


  }
  async count(): Promise<number> {
    try {
      const count = await this.blogModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
