import { Module } from '@nestjs/common';
import { MessagesModule } from './messages/messages.module';
import { MongooseModule } from '@nestjs/mongoose';
import 'dotenv/config';
import { TrustedModule } from './trustedby/trusted.module';
import { StacksModule } from './stacks/stacks.module';
import { OurteamModule } from './ourteam/ourteam.module';
import { UploadedFile } from './file-upload/upload.module';
import { ServicesModule } from './services/services.module';
import { DevelopmentsModule } from './developments/developments.module';
import { HandlebarsAdapter } from '@nestjs-modules/mailer/dist/adapters/handlebars.adapter';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { WelcomeModule } from './welcome/welcome.module';
import { ContactModule } from './contact/contact.module';
import { ReviewsModule } from './reviews/reviews.module';
import { EventsModule } from './events/events.module';
import { ExpertiseModule } from './expertise/expertise.module';
import { VacanciesModule } from './vacancies/vacancies.module';
import { BlogsModule } from './blogs/blogs.module';
import { Stats } from './stat/stats.module';
import { MailerModule } from '@nestjs-modules/mailer';
import { StatsModule } from './stats/stats.module';
import { MailsModule } from './mails/mails.module';
import { BlogCommentsModule } from './blog-comments/blog-comments.module';
import { CategoryModule } from './vacancies/category/category.module';
const path = require('path');
@Module({
  imports: [
    MongooseModule.forRoot(process.env.MONGODB_URL),
    MailerModule.forRoot({
      // Configure your mailer options here
      transport: {
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT,
        secure: false,
        auth: {
          user: process.env.MAIL_EMAIL,
          pass: process.env.MAIL_PASSWORD,
        },
      },
      defaults: {
        // Default mail options
      }
    }),
    MessagesModule,
    TrustedModule,
    StacksModule,
    OurteamModule,
    UploadedFile,
    ServicesModule,
    DevelopmentsModule,
    AuthModule,
    UserModule,
    WelcomeModule,
    ContactModule,
    ReviewsModule,
    EventsModule,
    ExpertiseModule,
    VacanciesModule,
    BlogsModule,
    Stats,
    StatsModule,
    MailsModule,
    BlogCommentsModule,
    CategoryModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule { }
