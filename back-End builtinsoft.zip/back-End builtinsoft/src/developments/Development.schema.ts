import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Developments extends Document {
    @Prop({ required: true, type: String })
    title: string;

    @Prop({ required: true, type: String })
    picture: string;

    @Prop({ required: true, type: String })
    logo: string;

    @Prop({ required: true, type: String })
    projecttheme: string;

    @Prop({ required: true, type: String })
    description: string;

    @Prop({ required: true, type: [String] })
    backEnd: string[];

    @Prop({ required: true, type: [String] })
    dataBase: string[];

    @Prop({ required: true, type: [String] })
    frontEnd: string[];

    @Prop({ type: String })
    appStoreLink: string;

    @Prop({ type: String })
    playStoreLink: string;

    @Prop({ type: String })
    webSiteLink: string;

    @Prop({ type: [String] })
    allPicture: string[];
}

export const DevelopmentsSchema = SchemaFactory.createForClass(Developments);
