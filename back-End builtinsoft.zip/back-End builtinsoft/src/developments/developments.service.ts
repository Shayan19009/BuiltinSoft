import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateDevelopmentDto } from './dto/create-development.dto';
import { UpdateDevelopmentDto } from './dto/update-development.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Developments } from 'src/developments/Development.schema';
import { Model } from 'mongoose';
import { ApiResponse } from 'src/dto/respose.dto';
import { UploadService } from 'src/file-upload/upload.service';


@Injectable()
export class DevelopmentsService {
  constructor(
    @InjectModel(Developments.name)
    private readonly developmentModel: Model<Developments>,
    private readonly uploadService: UploadService

  ) { }
  async create(createDevelopmentDto: CreateDevelopmentDto) {

    const createDevelopment = new this.developmentModel(createDevelopmentDto)
    return await createDevelopment.save()

  }

  async findAll() {
    return await this.developmentModel.find().sort({ createdAt: -1 })
  }

  async findOne(id: string) {
    return await this.developmentModel.findById({ _id: id });
  }

  async update(id: string, updateDevelopmentDto: UpdateDevelopmentDto) {

    return await this.developmentModel.findByIdAndUpdate(id, updateDevelopmentDto, { new: true });

  }

  async remove(id: string) {
    const development = await this.developmentModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(development.picture)
    images.push(development.logo)


    const deletedEvent = await this.developmentModel.findByIdAndDelete(id);

    if (!deletedEvent) {
      throw new NotFoundException(`developmrent with ID ${id} not found`);
    }
    if (images.length > 0) {
      const data = await this.uploadService.deleteFiles(images)

      return new ApiResponse(true, data, 'success', null)

    }

  }
  async count(): Promise<number> {
    try {
      const count = await this.developmentModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
