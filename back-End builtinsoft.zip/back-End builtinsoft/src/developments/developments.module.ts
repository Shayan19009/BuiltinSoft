import { Module } from '@nestjs/common';
import { DevelopmentsService } from './developments.service';
import { DevelopmentsController } from './developments.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Developments, DevelopmentsSchema } from 'src/developments/Development.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Developments.name, schema: DevelopmentsSchema },

    ]),
    UploadedFile
  ],
  controllers: [DevelopmentsController],
  providers: [DevelopmentsService],
  exports: [DevelopmentsService]
})
export class DevelopmentsModule { }
