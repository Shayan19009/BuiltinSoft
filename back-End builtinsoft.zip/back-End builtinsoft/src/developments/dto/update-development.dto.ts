// development.dto.ts

import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsArray, IsOptional } from 'class-validator';

export class UpdateDevelopmentDto {
    @IsOptional()
    @ApiProperty()
    @IsString()
    title?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    picture?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    logo?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    projecttheme?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    description?: string;

    @ApiProperty()
    @IsOptional()
    @IsArray()
    backEnd?: string[];

    @ApiProperty()
    @IsOptional()
    @IsArray()
    dataBase?: string[];

    @ApiProperty()
    @IsOptional()
    @IsArray()
    frontEnd?: string[];

    @ApiProperty()
    @IsOptional()
    @IsString()
    appStoreLink?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    playStoreLink?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    webSiteLink?: string;

    @ApiProperty()
    @IsOptional()
    @IsArray()
    allPicture?: string[];
}
