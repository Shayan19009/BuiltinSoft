// development.dto.ts

import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsArray, IsOptional } from 'class-validator';

export class CreateDevelopmentDto {
    @ApiProperty()
    @IsString()
    title: string;

    @ApiProperty()
    @IsString()
    picture: string;

    @ApiProperty()
    @IsString()
    logo: string;

    @ApiProperty()
    @IsString()
    projecttheme: string;

    @ApiProperty()
    @IsString()
    description: string;

    @ApiProperty()
    @IsArray()
    backEnd: string[];

    @ApiProperty()
    @IsArray()
    dataBase: string[];

    @ApiProperty()
    @IsArray()
    frontEnd: string[];

    @ApiProperty()
    @IsOptional()
    @IsString()
    appStoreLink?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    playStoreLink?: string;

    @ApiProperty()
    @IsOptional()
    @IsString()
    webSiteLink?: string;

    @ApiProperty()
    @IsArray()
    @IsOptional()
    allPicture?: string[];
}
