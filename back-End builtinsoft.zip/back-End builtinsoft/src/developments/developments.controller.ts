import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { DevelopmentsService } from './developments.service';
import { CreateDevelopmentDto } from './dto/create-development.dto';
import { UpdateDevelopmentDto } from './dto/update-development.dto';
import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';

@Controller('developments')
@ApiTags('Portfolio')
export class DevelopmentsController {
  constructor(private readonly developmentsService: DevelopmentsService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createDevelopmentDto: CreateDevelopmentDto) {
    try {
      const data = await this.developmentsService.create(createDevelopmentDto);
      if (data) {
        return new ApiResponse(true, data, 'added Successfully', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in adding ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }


  @Get('/count')
  @UseGuards(AccessTokenGuard)
  async count() {
    try {
      const data = await this.developmentsService.count();
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
  @Get()
  async findAll() {
    try {
      const data = await this.developmentsService.findAll();
      if (data) {
        return new ApiResponse(true, data, 'Success', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong  ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.developmentsService.findOne(id);
      if (data) {
        return new ApiResponse(true, data, 'Success', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong  ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error.message);
    }
  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  update(@Param('id') id: string, @Body() updateDevelopmentDto: UpdateDevelopmentDto) {
    try {
      const data = this.developmentsService.update(id, updateDevelopmentDto);
      if (data) {
        return new ApiResponse(true, data, 'updated Successfully', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in updating ',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  remove(@Param('id') id: string) {
    try {
      const data = this.developmentsService.remove(id);
      if (data) {
        return new ApiResponse(true, data, ' deleted Successfully', null);
      } else {
        return new ApiResponse(
          false,
          null,
          'something went wrong in deleting',
          null,
        );
      }
    } catch (error) {
      return new ApiResponse(false, null, 'error', error);
    }
  }
}
