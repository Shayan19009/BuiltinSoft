export enum AchievementType {
  Award = 'award',
  Certificate = 'certificate',
}
