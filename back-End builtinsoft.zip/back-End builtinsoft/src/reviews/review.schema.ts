import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

@Schema({ timestamps: true })
export class Review extends Document {
    @ApiProperty({ description: 'The name of the Review entity.' })
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    nameOfClient: string;

    @ApiProperty({ description: 'The name of the Review entity.' })
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    postOfClient: string;

    @ApiProperty({ description: 'The name of the trusted entity.' })
    @Prop({ required: true })
    @IsNotEmpty()
    @IsString()
    message: string;
}

export const ReviewSchema = SchemaFactory.createForClass(Review);
export type ReviewDocument = Review & Document;
