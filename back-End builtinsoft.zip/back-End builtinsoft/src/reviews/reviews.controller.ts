import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ReviewsService } from './reviews.service';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';
import { ApiTags } from '@nestjs/swagger';

@Controller('reviews')
@ApiTags('Reviews')
export class ReviewsController {
  constructor(private readonly reviewsService: ReviewsService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createReviewDto: CreateReviewDto) {
    try {
      const data = await this.reviewsService.create(createReviewDto);
      return new ApiResponse(true, data, 'deleted successfully', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }


  @Get()
  async findAll() {
    try {
      const data = await this.reviewsService.findAll();
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }

  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.reviewsService.findOne(id);
      return new ApiResponse(true, data, 'successfully', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }

  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateReviewDto: UpdateReviewDto) {
    try {
      const data = await this.reviewsService.update(id, updateReviewDto);
      return new ApiResponse(true, data, ' successfully', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }

  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.reviewsService.remove(id);
      return new ApiResponse(true, data, 'deleted successfully', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
}
