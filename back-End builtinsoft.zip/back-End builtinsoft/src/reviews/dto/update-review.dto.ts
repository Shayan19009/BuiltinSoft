import { PartialType } from '@nestjs/swagger';
import { CreateReviewDto } from './create-review.dto';
import { IsOptional, IsString } from 'class-validator';

export class UpdateReviewDto extends PartialType(CreateReviewDto) {
    @IsOptional()
    @IsString()
    readonly nameOfClient?: string;

    @IsOptional()
    @IsString()
    readonly postOfClient?: string;

    @IsOptional()
    @IsString()
    readonly message?: string;
}
