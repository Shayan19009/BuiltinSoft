import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class CreateReviewDto {

    @ApiProperty({ description: 'The name of the client.' })
    @IsNotEmpty()
    @IsString()
    readonly nameOfClient: string;

    @ApiProperty({ description: 'The post of the client.' })
    @IsNotEmpty()
    @IsString()
    readonly postOfClient: string;

    @ApiProperty({ description: 'The message in the review.' })
    @IsNotEmpty()
    @IsString()
    readonly message: string;
}
