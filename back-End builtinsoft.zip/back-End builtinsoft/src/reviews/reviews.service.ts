import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';
import { Review } from './review.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose'

@Injectable()
export class ReviewsService {
  constructor(
    @InjectModel(Review.name)
    private readonly reviewModel: Model<Review>,
  ) { }
  async create(createReviewDto: CreateReviewDto) {
    return await this.reviewModel.create(createReviewDto);
  }

  async findAll() {
    return await this.reviewModel.find().sort({ createdAt: -1 });
  }

  async findOne(id: string) {
    return await this.reviewModel.findById({ _id: id });

  }

  async update(id: string, updateReviewDto: UpdateReviewDto) {
    const updatedTrusted = await this.reviewModel.findByIdAndUpdate(
      id,
      updateReviewDto,
      { new: true },
    );
    if (!updatedTrusted) {
      throw new NotFoundException('Review record not found');
    }
    return updatedTrusted;
  }

  async remove(id: string) {
    const result = await this.reviewModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException('Review record not found');
    } else {
      return result;
    }
  }
  async count(): Promise<number> {
    try {
      const count = await this.reviewModel.countDocuments().exec();
      return count;
    } catch (error) {
      throw new Error('Error counting documents');
    }
  }
}
