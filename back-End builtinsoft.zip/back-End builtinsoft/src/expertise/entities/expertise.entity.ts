export class Expertise {}
