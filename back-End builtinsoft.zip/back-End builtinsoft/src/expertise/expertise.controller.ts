import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ExpertiseService } from './expertise.service';
import { CreateExpertiseDto } from './dto/create-expertise.dto';
import { UpdateExpertiseDto } from './dto/update-expertise.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';

@Controller('expertise')
@ApiTags('expertise')
export class ExpertiseController {
  constructor(private readonly expertiseService: ExpertiseService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createExpertiseDto: CreateExpertiseDto) {
    try {
      const data = await this.expertiseService.create(createExpertiseDto);
      if (data) {
        return new ApiResponse(true, data, 'created successfully');
      }
      else
        return new ApiResponse(false, null, 'Error', 'not fond or error in update');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.expertiseService.findAll();
      if (data)
        return new ApiResponse(true, data, ' success');
      else
        return new ApiResponse(false, null, 'Error', 'not fond or error in update');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.expertiseService.findOne(id);
      if (data)
        return new ApiResponse(true, data, ' success');
      else
        return new ApiResponse(false, null, 'Error', 'error in  geting / not fond');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateExpertiseDto: UpdateExpertiseDto) {
    try {
      const data = await this.expertiseService.update(id, updateExpertiseDto);
      return new ApiResponse(true, data, 'updated successfully');

    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.expertiseService.remove(id);
      return new ApiResponse(true, data, 'deleted successfully');
    } catch (error) {
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }
}
