import { IsNotEmpty, IsString, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateExpertiseDto {
    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    readonly picture: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    readonly image: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    readonly heading: string;

    @ApiProperty()
    @IsNotEmpty()
    @IsString()
    readonly description: string;
}

