import { PartialType } from '@nestjs/swagger';
import { CreateExpertiseDto } from './create-expertise.dto';
import { IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Optional } from '@nestjs/common';

export class UpdateExpertiseDto extends PartialType(CreateExpertiseDto) {

    @Optional()
    @IsString()
    readonly picture: string;

    @Optional()
    @IsString()
    readonly image: string;

    @Optional()
    @IsString()
    readonly heading: string;

    @Optional()
    @IsString()
    readonly description: string;
}

