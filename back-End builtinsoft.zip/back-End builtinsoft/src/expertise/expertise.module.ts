import { Module } from '@nestjs/common';
import { ExpertiseService } from './expertise.service';
import { ExpertiseController } from './expertise.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Expertise, ExpertiseSchema } from './expertise.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Expertise.name, schema: ExpertiseSchema }
    ]),
    UploadedFile
  ],
  controllers: [ExpertiseController],
  providers: [ExpertiseService],
  exports: [ExpertiseService]
})
export class ExpertiseModule { }
