import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateExpertiseDto } from './dto/create-expertise.dto';
import { UpdateExpertiseDto } from './dto/update-expertise.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Expertise } from './expertise.schema';
import { Model } from 'mongoose';
import { ApiResponse } from 'src/dto/respose.dto';
import { UploadService } from 'src/file-upload/upload.service';

@Injectable()
export class ExpertiseService {
  constructor(
    @InjectModel(Expertise.name)
    private readonly expertiseModel: Model<Expertise>,
    private readonly uploadService: UploadService,

  ) { }

  async create(createExpertiseDto: CreateExpertiseDto) {

    const createdExpertise = new this.expertiseModel(createExpertiseDto);

    const data = await createdExpertise.save();


    return data
  }

  async findAll() {
    return await this.expertiseModel.find().sort({ createdAt: -1 }).exec();
  }

  async findOne(id: string) {
    const expertise = await this.expertiseModel.findById(id).exec();
    if (!expertise) {
      throw new NotFoundException(`Expertise with ID ${id} not found`);
    }
    return expertise;
  }

  async update(
    id: string,
    updateExpertiseDto: UpdateExpertiseDto,
  ): Promise<Expertise> {
    const updatedExpertise = await this.expertiseModel.findByIdAndUpdate(
      id,
      updateExpertiseDto,
      { new: true },
    );
    if (!updatedExpertise) {
      throw new NotFoundException(`Expertise with ID ${id} not found`);
    }
    return updatedExpertise;
  }
  async count(): Promise<number> {
    return this.expertiseModel.countDocuments().exec();
  }
  async remove(id: string) {

    const stack = await this.expertiseModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(stack.picture)
    images.push(stack.image)

    const result = await this.expertiseModel.deleteOne({ _id: id }).exec();
    if (result.deletedCount === 0) {
      throw new NotFoundException('Stack record not found');
    } else {

      if (images.length > 0) {
        const data = await this.uploadService.deleteFiles(images)

        return new ApiResponse(true, data, 'success', null)

      }
      return result;
    }
  }

}
