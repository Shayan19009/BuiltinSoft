import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import { IsNotEmpty, IsString } from "class-validator";

@Schema({ timestamps: true })
export class Expertise extends Document {
    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    picture: string;

    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    image: string;

    @Prop({ type: String, required: true })
    @IsNotEmpty()
    @IsString()
    heading: string;

    @Prop({
        type: String, required: true
    })
    @IsNotEmpty()
    @IsString()
    description: string;
}

export const ExpertiseSchema = SchemaFactory.createForClass(Expertise);
