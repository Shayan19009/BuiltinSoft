import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Messages extends Document {
  @Prop({ required: true })
  fullname: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ required: true, unique: true })
  phoneNumber: string;

  @Prop({ required: true })
  message: string;

  @Prop({ required: true })
  applyingOn: string;

  @Prop({ required: true })
  experience: string;


  @Prop({ required: true, type: String })
  cvofsender: string;
}

export const MessageSchema = SchemaFactory.createForClass(Messages);
