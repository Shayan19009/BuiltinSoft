import { Controller, Get, Post, Body } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { Messages } from './message.schema';
import { ApiResponse } from 'src/dto/respose.dto';
import { CreateMessageDto } from './dto/messges.dto';
import { ApiTags } from '@nestjs/swagger';
import { updateDto } from './dto/updatedto';

@Controller('messages')
@ApiTags('Apply Now')
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) { }

  @Get()
  async getAllMessages(): Promise<ApiResponse<Messages[]>> {
    return this.messagesService.getAllMessages();
  }

  @Post()
  async createMessage(@Body() messageData: CreateMessageDto, updateMessageDto: updateDto,
  ) {
    return await this.messagesService.createMessage(messageData);
  }
}
