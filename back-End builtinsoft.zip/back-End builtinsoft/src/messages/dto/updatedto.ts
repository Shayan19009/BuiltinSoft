import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsEmail } from 'class-validator';

export class updateDto {
    @IsString()
    @ApiProperty()
    userName: string;

    @IsEmail()
    @ApiProperty()
    email: string;

    @IsEmail()
    @ApiProperty()
    phoneNumber: string;

    @IsString()
    @ApiProperty()
    message: string;


    @IsString()
    @ApiProperty()
    applyingOn: string;

    @IsString()
    @ApiProperty()
    experience: string;


    @ApiProperty()
    cvofsender: string;
}
