import { PartialType } from '@nestjs/swagger';
import { CreateStatDto } from './create-stat.dto';
import { IsString } from 'class-validator';

export class UpdateStatDto extends PartialType(CreateStatDto) {

    @IsString()
    title?: string;

    @IsString()
    picture?: string;

    @IsString()
    count?: string;
}
