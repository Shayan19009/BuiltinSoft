import { IsNotEmpty, IsString } from "class-validator";

export class CreateStatDto {
    @IsNotEmpty()
    @IsString()
    title: string;

    @IsNotEmpty()
    @IsString()
    picture: string;

    @IsNotEmpty()
    @IsString()
    count: string;

}
