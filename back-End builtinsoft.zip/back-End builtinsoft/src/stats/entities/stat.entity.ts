export class Stat {}
