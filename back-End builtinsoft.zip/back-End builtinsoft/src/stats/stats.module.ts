import { Module } from '@nestjs/common';
import { StatsService } from './stats.service';
import { StatsController } from './stats.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Stats } from 'src/stat/stats.module';
import { StatsSchema } from './stats.schema';

@Module({
  imports: [
    MongooseModule.forFeature(
      [
        { name: Stats.name, schema: StatsSchema }
      ]
    )
  ],
  controllers: [StatsController],
  providers: [StatsService],
})
export class StatsModule { }
