import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";


@Schema({ timestamps: true })
export class Stats {
    @Prop({ required: true, type: String })
    title: string


    @Prop({ required: true, type: String })
    picture: string

    @Prop({ required: true, type: String })
    count: string

}

export const StatsSchema = SchemaFactory.createForClass(Stats);
export type StatsSchema = Stats & Document;