import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException } from '@nestjs/common';
import { StatsService } from './stats.service';
import { CreateStatDto } from './dto/create-stat.dto';
import { UpdateStatDto } from './dto/update-stat.dto';
import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';

@Controller('stats')
@ApiTags('Stats')
export class StatsController {
  constructor(private readonly statsService: StatsService) { }

  @Post()
  create(@Body() createStatDto: CreateStatDto) {
    try {
      const data = this.statsService.create(createStatDto);
      if (data)
        return new ApiResponse(true, data, 'success ', null)
      else
        throw new BadRequestException('un able to Add the stat')
    } catch (error) {
      return new ApiResponse(false, null, 'unexcepted error', error)
    }
  }

  @Get()
  findAll() {
    try {
      const data = this.statsService.findAll();
      if (data)
        return new ApiResponse(true, data, 'success', null)
      else
        throw new BadRequestException('un able to Add the stat')
    } catch (error) {
      return new ApiResponse(false, null, 'unexcepted error', error)
    }
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.statsService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateStatDto: UpdateStatDto) {
    return this.statsService.update(id, updateStatDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.statsService.remove(id);
  }
}
