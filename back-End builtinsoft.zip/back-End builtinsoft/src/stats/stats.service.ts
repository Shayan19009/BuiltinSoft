import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateStatDto } from './dto/create-stat.dto';
import { UpdateStatDto } from './dto/update-stat.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Stats } from './stats.schema';

@Injectable()
export class StatsService {
  constructor(
    @InjectModel(Stats.name)
    private readonly statModel: Model<Stats>,
  ) { }

  async create(createStatDto: CreateStatDto): Promise<Stats> {
    const createdStat = new this.statModel(createStatDto);
    return createdStat.save();
  }

  async findAll(): Promise<Stats[]> {
    return this.statModel.find().exec();
  }

  async findOne(id: string): Promise<Stats> {
    const stat = await this.statModel.findById(id).exec();
    if (!stat) {
      throw new NotFoundException(`Stat with ID ${id} not found`);
    }
    return stat;
  }

  async update(id: string, updateStatDto: UpdateStatDto): Promise<Stats> {
    const updatedStat = await this.statModel.findByIdAndUpdate(
      id,
      updateStatDto,
      { new: true },
    );
    if (!updatedStat) {
      throw new NotFoundException(`Stat with ID ${id} not found`);
    }
    return updatedStat;
  }

  async remove(id: string): Promise<Stats> {
    const removedStat = await this.statModel.findByIdAndRemove(id);
    if (!removedStat) {
      throw new NotFoundException(`Stat with ID ${id} not found`);
    }
    return removedStat;
  }
}
