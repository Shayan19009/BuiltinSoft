import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Service extends Document {
  // @Prop({ required: true })
  // picture: string;

  @ApiProperty({ description: 'The picture associated with the service.' })
  @Prop({ required: true })
  @IsNotEmpty()
  @IsString()
  picture: string;

  @ApiProperty({ description: 'The name of the trusted entity.' })
  @Prop({ required: true })
  @IsNotEmpty()
  @IsString()
  heading: string;

  @ApiProperty({ description: 'The name of the trusted entity.' })
  @Prop({ required: true })
  @IsNotEmpty()
  @IsString()
  description: string;

  // @Prop({ required: true })
  // conciseDescription: string; 
}

export const ServiceSchema = SchemaFactory.createForClass(Service);
