import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as fs from 'fs/promises';


@Injectable()
export class UploadService {
    constructor() { }

    async fileExists(filePath: string): Promise<boolean> {
        try {
            await fs.access(filePath, fs.constants.F_OK);
            return true;
        } catch (error) {
            return false;
        }
    }

    async deleteFiles(filePaths: string[]) {
        const results: string[] = [];

        for (const path of filePaths) {
            try {
                const filePath = `./public/uploads/${path}`
                if (await this.fileExists(filePath)) {
                    await fs.unlink(filePath);
                    results.push(`File deleted: ${filePath}`);
                } else {
                    results.push(`File not found: ${filePath}`);
                }
            } catch (error) {
                results.push(`Error deleting ${path}: ${error.message}`);
            }
        }


        return null;
    }
}
