import { Module } from '@nestjs/common';
import { FileUploadController } from './upload';
import { UploadService } from './upload.service';

@Module({

  controllers: [FileUploadController],
  providers: [UploadService],
  exports: [UploadService]
})
export class UploadedFile { }
