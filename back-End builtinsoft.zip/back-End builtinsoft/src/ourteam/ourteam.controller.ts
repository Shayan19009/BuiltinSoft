import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { OurteamService } from './ourteam.service';
import { CreateTeamDto } from './dto/create-ourteam.dto';
import { UpdateTeamDto } from './dto/update-ourteam.dto';

import { ApiTags } from '@nestjs/swagger';
import { ApiResponse } from 'src/dto/respose.dto';
import { AccessTokenGuard } from 'src/common/guards/AccessToken.guard';


@Controller('ourteam')
@ApiTags('OurTeam')
export class OurteamController {
  constructor(private readonly ourteamService: OurteamService) { }

  @Post()
  @UseGuards(AccessTokenGuard)
  async create(@Body() createOurteamDto: CreateTeamDto) {
    try {
      const data = await this.ourteamService.create(createOurteamDto);
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get()
  async findAll() {
    try {
      const data = await this.ourteamService.findAll();
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get('/count')
  @UseGuards(AccessTokenGuard)
  async count() {
    try {
      const data = await this.ourteamService.count();
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.ourteamService.findOne(id);
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Patch(':id')
  @UseGuards(AccessTokenGuard)
  async update(@Param('id') id: string, @Body() updateOurteamDto: UpdateTeamDto) {
    try {
      const data = await this.ourteamService.update(id, updateOurteamDto);
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }

  @Delete(':id')
  @UseGuards(AccessTokenGuard)
  async remove(@Param('id') id: string) {
    try {
      const data = await this.ourteamService.remove(id);
      return new ApiResponse(true, data, 'success', null);
    } catch (error) {
      console.log(error);
      return new ApiResponse(false, null, 'Error', error.message);
    }
  }


}
