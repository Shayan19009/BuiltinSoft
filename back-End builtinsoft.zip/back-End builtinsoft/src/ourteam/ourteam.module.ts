import { Module } from '@nestjs/common';
import { OurteamService } from './ourteam.service';
import { OurteamController } from './ourteam.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { TeamDocument } from './ourteam.schema';
import { UploadedFile } from 'src/file-upload/upload.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Team', schema: TeamDocument }]),
    UploadedFile

  ],
  controllers: [OurteamController],
  providers: [OurteamService],
  exports: [OurteamService]
})
export class OurteamModule { }
