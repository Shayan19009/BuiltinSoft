import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Team, TeamDocument } from './ourteam.schema';
import { CreateTeamDto } from './dto/create-ourteam.dto';
import { ApiResponse } from 'src/dto/respose.dto';
import { UploadService } from 'src/file-upload/upload.service';

@Injectable()
export class OurteamService {
  constructor(
    @InjectModel(Team.name) private readonly teamModel: Model<TeamDocument>,
    private readonly uploadService: UploadService

  ) { }

  async create(createTeamDto: CreateTeamDto): Promise<Team> {
    const createdTeam = new this.teamModel(createTeamDto);
    return await createdTeam.save();
  }

  async findAll(): Promise<Team[]> {
    return await this.teamModel.find().sort({ createdAt: -1 });
  }

  async findOne(id: string): Promise<Team> {
    return await this.teamModel.findById(id).exec();
  }

  async update(id: string, updateTeamDto: CreateTeamDto): Promise<Team> {
    return await this.teamModel.findByIdAndUpdate(id, updateTeamDto, { new: true }).exec();
  }

  async remove(id: string) {

    const development = await this.teamModel.findById({ _id: id }).exec();
    var images: any[] = [];
    images.push(development.picture)



    const deletedEvent = await this.teamModel.findByIdAndRemove(id).exec();


    if (!deletedEvent) {
      throw new NotFoundException(`developmrent with ID ${id} not found`);
    }
    if (images.length > 0) {
      const data = await this.uploadService.deleteFiles(images)

      return new ApiResponse(true, data, 'success', null)

    }


  }

  async count(): Promise<number> {
    return this.teamModel.countDocuments().exec();
  }
}
